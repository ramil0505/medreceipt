/**
 * seed-extra.js — Additional seed for stress-testing & demo variety
 * Run AFTER seed.js: node seed-extra.js
 * Does NOT clear existing data — only adds more patients and prescriptions.
 */
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { connectDB } from './config/db.js';
import User from './models/User.js';
import Prescription from './models/Prescription.js';
import AuditLog from './models/AuditLog.js';
import mongoose from 'mongoose';

async function run() {
  await connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/medreceipt');

  const doctors = await User.find({ role: 'DOCTOR', isActive: true });
  if (doctors.length === 0) {
    console.error('[seed-extra] No doctors found. Run seed.js first.');
    process.exit(1);
  }

  const house = doctors.find(d => d.email.includes('house')) || doctors[0];
  const wilson = doctors.find(d => d.email.includes('wilson')) || doctors[0];
  const cuddy = doctors.find(d => d.email.includes('cuddy')) || doctors[0];

  const pw = await bcrypt.hash('Patient!Pass123', 12);
  const day = 24 * 60 * 60 * 1000;
  const now = Date.now();

  const extraPatients = await User.create([
    {
      fullName: 'Gundars Āboliņš',
      email: 'gundars@medreceipt.io', passwordHash: pw,
      personalId: 'PA-241007', phone: '+371-20111228', role: 'PATIENT',
      dateOfBirth: new Date('1943-07-19'), bloodType: 'A-',
      allergies: 'Iodine contrast media, NSAIDs',
      address: 'Čaka iela 55, Rīga, LV-1011',
      emergencyContact: 'Ilze Āboliņa +371-20111107',
      notes: 'Elderly patient. Requires simplified instructions.',
      isVerified: true, isActive: true,
    },
    {
      fullName: 'Helēna Vītoliņa',
      email: 'helena@medreceipt.io', passwordHash: pw,
      personalId: 'PA-241008', phone: '+371-20111229', role: 'PATIENT',
      dateOfBirth: new Date('1998-12-01'), bloodType: 'B+',
      allergies: 'None known',
      isVerified: true, isActive: true,
    },
    {
      fullName: 'Ivars Mežsargs',
      email: 'ivars@medreceipt.io', passwordHash: pw,
      personalId: 'PA-241009', phone: '+371-20111230', role: 'PATIENT',
      dateOfBirth: new Date('1970-05-14'), bloodType: 'O+',
      allergies: 'Cephalosporins',
      isVerified: true, isActive: true,
    },
  ]);

  const [gundars, helena, ivars] = extraPatients;

  const rxDefs = [
    {
      patient: gundars, doctor: house,
      diagnosis: 'Congestive heart failure — routine maintenance',
      medication: 'Furosemide 40 mg tablets',
      dosage: 'Once daily in the morning',
      instructions: 'Monitor daily weight. Report weight gain >2 kg overnight. Restrict fluid to 1.5 L/day.',
      status: 'ACTIVE', daysExpiry: 60,
    },
    {
      patient: gundars, doctor: house,
      diagnosis: 'Atrial fibrillation — anticoagulation',
      medication: 'Warfarin 5 mg tablets',
      dosage: 'Dose per INR — currently 5 mg daily',
      instructions: 'INR check every 4 weeks. Avoid cranberry juice and large changes in vitamin K intake.',
      status: 'ACTIVE', daysExpiry: 30,
    },
    {
      patient: gundars, doctor: cuddy,
      diagnosis: 'Hypothyroidism — established',
      medication: 'Levothyroxine 75 mcg tablets',
      dosage: '1 tablet daily, 30 minutes before breakfast',
      instructions: 'Do not take with calcium or iron supplements. TSH check in 3 months.',
      status: 'DISPENSED', daysExpiry: -10,
    },
    {
      patient: helena, doctor: wilson,
      diagnosis: 'Anxiety disorder — generalised',
      medication: 'Sertraline 50 mg tablets',
      dosage: 'Once daily with food',
      instructions: 'Allow 4 weeks for full effect. Do not stop abruptly. Avoid alcohol.',
      status: 'ACTIVE', daysExpiry: 90,
    },
    {
      patient: helena, doctor: wilson,
      diagnosis: 'Insomnia — short-term',
      medication: 'Melatonin 2 mg modified-release tablets',
      dosage: '1 tablet 1 hour before bedtime',
      instructions: 'Use only for short-term (max 3 weeks). Avoid screens before bed.',
      status: 'EXPIRED', daysExpiry: -20,
    },
    {
      patient: ivars, doctor: house,
      diagnosis: 'Peptic ulcer — H. pylori eradication',
      medication: 'Omeprazole 20 mg + Amoxicillin 1g + Clarithromycin 500 mg (triple therapy kit)',
      dosage: 'Twice daily for 7 days',
      instructions: 'Complete the full course. Avoid alcohol. Take omeprazole 30 min before meals.',
      status: 'DISPENSED', daysExpiry: -5,
    },
    {
      patient: ivars, doctor: house,
      diagnosis: 'Peptic ulcer — maintenance',
      medication: 'Omeprazole 20 mg capsules',
      dosage: 'Once daily before breakfast',
      instructions: 'Maintenance therapy for 4 weeks post-eradication. Report black stools.',
      status: 'ACTIVE', daysExpiry: 28,
    },
    {
      patient: ivars, doctor: cuddy,
      diagnosis: 'Type 2 diabetes — newly diagnosed',
      medication: 'Metformin 500 mg tablets',
      dosage: 'Once daily with main meal (week 1-2), then twice daily',
      instructions: 'Start low to minimise GI side effects. Monitor fasting glucose. HbA1c in 3 months.',
      status: 'ACTIVE', daysExpiry: 90,
    },
  ];

  for (const def of rxDefs) {
    const rx = new Prescription({
      patientId: def.patient._id,
      doctorId: def.doctor._id,
      diagnosis: def.diagnosis,
      medication: def.medication,
      dosage: def.dosage,
      instructions: def.instructions,
      status: 'DRAFT',
    });
    await rx.save();

    if (def.status !== 'DRAFT') {
      rx.status = 'ACTIVE';
      rx.signedAt = new Date(now - Math.random() * 20 * day);
      rx.signatureHash = rx.computeSignature(def.doctor._id);
      rx.expiresAt = new Date(now + def.daysExpiry * day);
      await rx.save();
    }
    if (def.status === 'DISPENSED') { rx.status = 'DISPENSED'; await rx.save(); }
    if (def.status === 'EXPIRED') { rx.status = 'EXPIRED'; await rx.save(); }
  }

  // Extra audit events
  await AuditLog.create([
    { actorId: gundars._id, actorEmail: gundars.email, eventType: 'USER_LOGIN_SUCCESS', ipAddress: '84.237.11.30', success: true, createdAt: new Date(now - 3 * 3600000) },
    { actorId: house._id, actorEmail: house.email, eventType: 'PATIENT_VIEWED', resourceType: 'USER', resourceId: String(gundars._id), ipAddress: '192.168.1.20', success: true, createdAt: new Date(now - 2 * 3600000) },
    { actorId: wilson._id, actorEmail: wilson.email, eventType: 'PRESCRIPTION_SIGNED', resourceType: 'PRESCRIPTION', ipAddress: '10.0.0.5', success: true, createdAt: new Date(now - 1 * 3600000) },
    { actorId: gundars._id, actorEmail: gundars.email, eventType: 'USER_LOGIN_FAILED', ipAddress: '84.237.11.30', success: false, metadata: { reason: 'wrong_password' }, createdAt: new Date(now - 4 * 3600000) },
  ]);

  console.log('\n[seed-extra] ✅ done');
  console.log('  Added 3 extra patients + 8 prescriptions + 4 audit events');
  console.log('  Patient: gundars@medreceipt.io  / Patient!Pass123');
  console.log('  Patient: helena@medreceipt.io   / Patient!Pass123');
  console.log('  Patient: ivars@medreceipt.io    / Patient!Pass123\n');

  await mongoose.disconnect();
}

run().catch((err) => { console.error(err); process.exit(1); });
