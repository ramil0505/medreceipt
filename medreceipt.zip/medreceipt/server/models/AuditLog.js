import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema(
  {
    actorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
    actorEmail: { type: String }, // denormalized for resilience
    eventType: { type: String, required: true, index: true },
    resourceType: { type: String },
    resourceId: { type: String, index: true },
    ipAddress: { type: String },
    userAgent: { type: String },
    metadata: { type: Object },
    success: { type: Boolean, default: true },
  },
  { timestamps: { createdAt: 'createdAt', updatedAt: false } }
);

auditLogSchema.index({ actorId: 1, createdAt: -1 });

// Block updates / deletes — append-only per SDD
auditLogSchema.pre('updateOne', function () {
  throw new Error('audit_log is append-only');
});
auditLogSchema.pre('findOneAndUpdate', function () {
  throw new Error('audit_log is append-only');
});
auditLogSchema.pre('deleteOne', function () {
  throw new Error('audit_log is append-only');
});
auditLogSchema.pre('findOneAndDelete', function () {
  throw new Error('audit_log is append-only');
});

export default mongoose.model('AuditLog', auditLogSchema);
