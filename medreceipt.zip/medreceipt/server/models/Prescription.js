import mongoose from 'mongoose';
import crypto from 'crypto';

const prescriptionSchema = new mongoose.Schema(
  {
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    doctorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    diagnosis: { type: String, required: true },
    medication: { type: String, required: true, maxlength: 500 },
    dosage: { type: String, required: true, maxlength: 200 },
    instructions: { type: String, required: true },
    signatureHash: { type: String }, // SHA-256 of doctorId + prescriptionId + timestamp
    status: {
      type: String,
      enum: ['DRAFT', 'ACTIVE', 'DISPENSED', 'EXPIRED'],
      default: 'DRAFT',
      index: true,
    },
    expiresAt: { type: Date },
    signedAt: { type: Date },
  },
  { timestamps: true }
);

prescriptionSchema.index({ status: 1, expiresAt: 1 });

prescriptionSchema.methods.computeSignature = function (doctorId) {
  return crypto
    .createHash('sha256')
    .update(`${doctorId}:${this._id}:${Date.now()}`)
    .digest('hex');
};

// Enforce immutability of medical content after signing
prescriptionSchema.pre('save', function (next) {
  if (!this.isNew && this.status !== 'DRAFT') {
    const lockedFields = ['diagnosis', 'medication', 'dosage', 'instructions'];
    for (const f of lockedFields) {
      if (this.isModified(f)) {
        return next(new Error(`Field "${f}" is immutable after signing`));
      }
    }
  }
  next();
});

export default mongoose.model('Prescription', prescriptionSchema);
