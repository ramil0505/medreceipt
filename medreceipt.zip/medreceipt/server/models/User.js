import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, maxlength: 200 },
    email: { type: String, required: true, unique: true, lowercase: true, maxlength: 320 },
    passwordHash: { type: String, required: true },
    personalId: { type: String, required: true, unique: true, maxlength: 50 },
    phone: { type: String, required: true, maxlength: 30 },
    role: { type: String, enum: ['DOCTOR', 'PATIENT', 'ADMIN'], required: true },
    licenseNumber: { type: String },
    specialty: { type: String },
    department: { type: String },
    dateOfBirth: { type: Date },
    address: { type: String, maxlength: 500 },
    emergencyContact: { type: String, maxlength: 200 },
    bloodType: { type: String, enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', ''] },
    allergies: { type: String, maxlength: 1000 },
    notes: { type: String, maxlength: 2000 },
    totpSecret: { type: String },
    totpPending: { type: String }, // Unconfirmed secret during MFA setup
    mfaEnabled: { type: Boolean, default: false },
    isVerified: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    failedLoginAttempts: { type: Number, default: 0 },
    lockoutUntil: { type: Date },
    lastLoginAt: { type: Date },
    passwordChangedAt: { type: Date },
  },
  { timestamps: true }
);

userSchema.index({ role: 1 });
userSchema.index({ isActive: 1 });

userSchema.methods.toSafeJSON = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  delete obj.totpSecret;
  delete obj.totpPending;
  delete obj.failedLoginAttempts;
  delete obj.lockoutUntil;
  return obj;
};

export default mongoose.model('User', userSchema);
