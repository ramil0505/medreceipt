import jwt from 'jsonwebtoken';

// In-memory JWT blacklist (Redis-backed in production per SDD)
const blacklistedJtis = new Map();

export function blacklistJti(jti, expSeconds) {
  blacklistedJtis.set(jti, Date.now() + expSeconds * 1000);
  // simple cleanup
  for (const [k, v] of blacklistedJtis.entries()) {
    if (v < Date.now()) blacklistedJtis.delete(k);
  }
}

export function isBlacklisted(jti) {
  const v = blacklistedJtis.get(jti);
  if (!v) return false;
  if (v < Date.now()) {
    blacklistedJtis.delete(jti);
    return false;
  }
  return true;
}

export function verifyJWT(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth?.startsWith('Bearer ')) {
    return res
      .status(401)
      .json({ error: { code: 'NO_TOKEN', message: 'Missing bearer token.' } });
  }
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.type === 'preauth') {
      return res.status(401).json({
        error: { code: 'PREAUTH_TOKEN', message: 'MFA verification required.' },
      });
    }
    if (payload.jti && isBlacklisted(payload.jti)) {
      return res
        .status(401)
        .json({ error: { code: 'TOKEN_REVOKED', message: 'Token has been revoked.' } });
    }
    req.user = {
      id: payload.sub,
      role: payload.role,
      email: payload.email,
      jti: payload.jti,
      exp: payload.exp,
    };
    next();
  } catch (err) {
    return res
      .status(401)
      .json({ error: { code: 'INVALID_TOKEN', message: 'Invalid or expired token.' } });
  }
}
