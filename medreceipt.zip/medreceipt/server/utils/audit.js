import AuditLog from '../models/AuditLog.js';

export async function logEvent({
  actorId,
  actorEmail,
  eventType,
  resourceType,
  resourceId,
  req,
  metadata,
  success = true,
}) {
  try {
    await AuditLog.create({
      actorId,
      actorEmail,
      eventType,
      resourceType,
      resourceId: resourceId ? String(resourceId) : undefined,
      ipAddress: req?.ip,
      userAgent: req?.headers?.['user-agent'],
      metadata,
      success,
    });
  } catch (err) {
    // Audit must never break the request flow, but the error must surface.
    console.error('[audit] failed to log event', err);
  }
}
