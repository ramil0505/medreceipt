import 'dotenv/config';
import bcrypt from 'bcryptjs';
import speakeasy from 'speakeasy';
import { connectDB } from './config/db.js';
import User from './models/User.js';
import Prescription from './models/Prescription.js';
import AuditLog from './models/AuditLog.js';
import mongoose from 'mongoose';

async function run() {
  await connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/medreceipt');
  console.log('[seed] clearing existing data…');
  await Promise.all([User.deleteMany({}), Prescription.deleteMany({}), AuditLog.deleteMany({})]);

  // --- MFA secrets ---
  const houseTotp = speakeasy.generateSecret({ name: 'MedReceipt:dr.house@medreceipt.io', length: 20 });
  const wilsonTotp = speakeasy.generateSecret({ name: 'MedReceipt:dr.wilson@medreceipt.io', length: 20 });

  const houseCurrent = speakeasy.totp({ secret: houseTotp.base32, encoding: 'base32' });
  const wilsonCurrent = speakeasy.totp({ secret: wilsonTotp.base32, encoding: 'base32' });

  // --- Users ---
  const [admin, house, wilson, cuddy, alice, bob, carol, david, emma, frank] = await User.create([
    {
      fullName: 'Admin Operator',
      email: 'admin@medreceipt.io',
      passwordHash: await bcrypt.hash('Admin!Pass123', 12),
      personalId: 'ADM-001',
      phone: '+371-20000099',
      role: 'ADMIN',
      isVerified: true,
      isActive: true,
      lastLoginAt: new Date(Date.now() - 3600000),
    },
    {
      fullName: 'Dr. Gregory House',
      email: 'dr.house@medreceipt.io',
      passwordHash: await bcrypt.hash('Doctor!Pass123', 12),
      personalId: 'DOC-001',
      phone: '+371-20000001',
      role: 'DOCTOR',
      licenseNumber: 'MD-2026-0142',
      specialty: 'Diagnostic Medicine',
      department: 'Internal Medicine',
      totpSecret: houseTotp.base32,
      mfaEnabled: true,
      isVerified: true,
      isActive: true,
      lastLoginAt: new Date(Date.now() - 7200000),
    },
    {
      fullName: 'Dr. James Wilson',
      email: 'dr.wilson@medreceipt.io',
      passwordHash: await bcrypt.hash('Doctor!Pass123', 12),
      personalId: 'DOC-002',
      phone: '+371-20000002',
      role: 'DOCTOR',
      licenseNumber: 'MD-2026-0201',
      specialty: 'Oncology',
      department: 'Oncology Ward',
      totpSecret: wilsonTotp.base32,
      mfaEnabled: true,
      isVerified: true,
      isActive: true,
      lastLoginAt: new Date(Date.now() - 86400000),
    },
    {
      fullName: 'Dr. Lisa Cuddy',
      email: 'dr.cuddy@medreceipt.io',
      passwordHash: await bcrypt.hash('Doctor!Pass123', 12),
      personalId: 'DOC-003',
      phone: '+371-20000003',
      role: 'DOCTOR',
      licenseNumber: 'MD-2026-0188',
      specialty: 'Endocrinology',
      department: 'Endocrinology',
      mfaEnabled: false,
      isVerified: true,
      isActive: true,
    },
    {
      fullName: 'Alice Bērziņa',
      email: 'alice@medreceipt.io',
      passwordHash: await bcrypt.hash('Patient!Pass123', 12),
      personalId: 'PA-241001',
      phone: '+371-20111222',
      role: 'PATIENT',
      dateOfBirth: new Date('1991-04-12'),
      bloodType: 'A+',
      allergies: 'Penicillin, Sulfa drugs',
      address: 'Brīvības iela 42, Rīga, LV-1011',
      emergencyContact: 'Jānis Bērziņš +371-20111100',
      isVerified: true,
      isActive: true,
      lastLoginAt: new Date(Date.now() - 3600000 * 2),
    },
    {
      fullName: 'Bobis Kalniņš',
      email: 'bob@medreceipt.io',
      passwordHash: await bcrypt.hash('Patient!Pass123', 12),
      personalId: 'PA-241002',
      phone: '+371-20111223',
      role: 'PATIENT',
      dateOfBirth: new Date('1978-08-30'),
      bloodType: 'O-',
      allergies: 'Aspirin',
      address: 'Tērbatas iela 15, Rīga, LV-1011',
      emergencyContact: 'Anna Kalniņa +371-20111101',
      isVerified: true,
      isActive: true,
      lastLoginAt: new Date(Date.now() - 86400000 * 2),
    },
    {
      fullName: 'Carol Ozoliņa',
      email: 'carol@medreceipt.io',
      passwordHash: await bcrypt.hash('Patient!Pass123', 12),
      personalId: 'PA-241003',
      phone: '+371-20111224',
      role: 'PATIENT',
      dateOfBirth: new Date('1965-01-15'),
      bloodType: 'B+',
      allergies: 'None known',
      address: 'Lāčplēša iela 7, Rīga, LV-1011',
      emergencyContact: 'Māris Ozoliņš +371-20111102',
      isVerified: true,
      isActive: true,
      lastLoginAt: new Date(Date.now() - 86400000 * 5),
    },
    {
      fullName: 'Dāvis Liepiņš',
      email: 'davis@medreceipt.io',
      passwordHash: await bcrypt.hash('Patient!Pass123', 12),
      personalId: 'PA-241004',
      phone: '+371-20111225',
      role: 'PATIENT',
      dateOfBirth: new Date('1955-11-03'),
      bloodType: 'AB+',
      allergies: 'Codeine, Latex',
      address: 'Dzirnavu iela 33, Rīga, LV-1010',
      emergencyContact: 'Laima Liepiņa +371-20111103',
      notes: 'Patient has mild hearing impairment. Prefers written communication.',
      isVerified: true,
      isActive: true,
    },
    {
      fullName: 'Emma Siliņa',
      email: 'emma@medreceipt.io',
      passwordHash: await bcrypt.hash('Patient!Pass123', 12),
      personalId: 'PA-241005',
      phone: '+371-20111226',
      role: 'PATIENT',
      dateOfBirth: new Date('2001-06-22'),
      bloodType: 'A-',
      allergies: 'Pollen (seasonal), Dust mites',
      address: 'Stabu iela 12, Rīga, LV-1011',
      isVerified: true,
      isActive: true,
    },
    {
      fullName: 'Frančeska Krūmiņa',
      email: 'frank@medreceipt.io',
      passwordHash: await bcrypt.hash('Patient!Pass123', 12),
      personalId: 'PA-241006',
      phone: '+371-20111227',
      role: 'PATIENT',
      dateOfBirth: new Date('1982-03-09'),
      bloodType: 'O+',
      allergies: 'None known',
      isVerified: true,
      isActive: true,
    },
  ]);

  // --- Prescriptions ---
  const now = new Date();
  const day = 24 * 60 * 60 * 1000;

  const rxDefs = [
    // Alice prescriptions
    {
      patient: alice, doctor: house,
      diagnosis: 'Acute bacterial sinusitis',
      medication: 'Amoxicillin 500 mg capsules',
      dosage: '1 capsule three times daily',
      instructions: 'Take with food. Complete the full 7-day course even if symptoms improve.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 25 * day),
    },
    {
      patient: alice, doctor: house,
      diagnosis: 'Seasonal allergic rhinitis',
      medication: 'Cetirizine 10 mg tablets',
      dosage: 'Once daily, in the morning',
      instructions: 'Avoid combining with alcohol. Drowsiness possible.',
      status: 'DISPENSED',
      expiresAt: new Date(now.getTime() - 5 * day),
    },
    {
      patient: alice, doctor: wilson,
      diagnosis: 'Iron-deficiency anaemia',
      medication: 'Ferrous sulfate 200 mg tablets',
      dosage: 'One tablet twice daily with meals',
      instructions: 'Take with orange juice to improve absorption. Avoid dairy within 2 hours.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 60 * day),
    },
    // Bob prescriptions
    {
      patient: bob, doctor: house,
      diagnosis: 'Hypertension follow-up',
      medication: 'Lisinopril 10 mg tablets',
      dosage: 'Once daily',
      instructions: 'Monitor blood pressure weekly. Report dizziness or dry cough immediately.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 30 * day),
    },
    {
      patient: bob, doctor: house,
      diagnosis: 'Hyperlipidaemia',
      medication: 'Atorvastatin 20 mg tablets',
      dosage: 'Once daily at bedtime',
      instructions: 'Avoid grapefruit juice. Report any muscle pain or weakness.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 90 * day),
    },
    {
      patient: bob, doctor: cuddy,
      diagnosis: 'Type 2 diabetes mellitus — routine',
      medication: 'Metformin 850 mg tablets',
      dosage: 'Twice daily with meals',
      instructions: 'Monitor fasting glucose daily. Maintain fluid intake.',
      status: 'EXPIRED',
      expiresAt: new Date(now.getTime() - 10 * day),
    },
    // Carol prescriptions
    {
      patient: carol, doctor: cuddy,
      diagnosis: 'Type 2 diabetes management',
      medication: 'Metformin 500 mg tablets',
      dosage: 'Twice daily with meals',
      instructions: 'Stay hydrated. Monitor glucose 2× per day. Follow low-GI diet.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 45 * day),
    },
    {
      patient: carol, doctor: house,
      diagnosis: 'Osteoporosis prophylaxis',
      medication: 'Calcium carbonate 500 mg + Vitamin D3 400 IU',
      dosage: 'One tablet twice daily with meals',
      instructions: 'Do not take with iron supplements or thyroid medication.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 120 * day),
    },
    {
      patient: carol, doctor: cuddy,
      diagnosis: 'Hypothyroidism follow-up',
      medication: 'Levothyroxine 50 mcg tablets',
      dosage: 'Once daily, 30 minutes before breakfast',
      instructions: 'Do not switch brands without consulting. Re-check TSH in 6 weeks.',
      status: 'DRAFT',
    },
    // David prescriptions
    {
      patient: david, doctor: house,
      diagnosis: 'Chronic lower back pain',
      medication: 'Ibuprofen 400 mg tablets',
      dosage: 'Three times daily with food, maximum 5 days',
      instructions: 'Avoid alcohol. Do not use if stomach pain develops.',
      status: 'DISPENSED',
      expiresAt: new Date(now.getTime() - 2 * day),
    },
    {
      patient: david, doctor: wilson,
      diagnosis: 'Prostate hyperplasia (BPH)',
      medication: 'Tamsulosin 0.4 mg capsules',
      dosage: 'One capsule daily after breakfast',
      instructions: 'Avoid driving until you know how this medication affects you.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 60 * day),
    },
    // Emma prescriptions
    {
      patient: emma, doctor: house,
      diagnosis: 'Moderate persistent asthma',
      medication: 'Salbutamol 100 mcg inhaler',
      dosage: '1-2 puffs as needed (max 8 puffs/day)',
      instructions: 'Rinse mouth after use. Carry at all times. Review if used >3 days/week.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 180 * day),
    },
    {
      patient: emma, doctor: house,
      diagnosis: 'Moderate persistent asthma — preventer',
      medication: 'Fluticasone 125 mcg inhaler',
      dosage: '1 puff twice daily',
      instructions: 'Must be taken regularly even when symptom-free. Do not stop suddenly.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 180 * day),
    },
    // Frank prescriptions
    {
      patient: frank, doctor: wilson,
      diagnosis: 'Migraine prophylaxis',
      medication: 'Propranolol 40 mg tablets',
      dosage: 'Twice daily',
      instructions: 'Do not stop abruptly. Monitor heart rate. Avoid if asthmatic.',
      status: 'ACTIVE',
      expiresAt: new Date(now.getTime() + 90 * day),
    },
    {
      patient: frank, doctor: wilson,
      diagnosis: 'Acute migraine',
      medication: 'Sumatriptan 50 mg tablets',
      dosage: '1 tablet at onset; repeat after 2h if needed (max 2 tablets/day)',
      instructions: 'Do not use within 24h of ergotamine. Seek help if chest tightness occurs.',
      status: 'DISPENSED',
      expiresAt: new Date(now.getTime() - 3 * day),
    },
  ];

  const doctors = { house, wilson, cuddy };
  const createdRx = [];

  for (const def of rxDefs) {
    const rx = new Prescription({
      patientId: def.patient._id,
      doctorId: def.doctor._id,
      diagnosis: def.diagnosis,
      medication: def.medication,
      dosage: def.dosage,
      instructions: def.instructions,
      status: 'DRAFT',
    });
    await rx.save();

    if (def.status !== 'DRAFT') {
      rx.status = 'ACTIVE';
      rx.signedAt = new Date(Date.now() - Math.random() * 15 * day);
      rx.signatureHash = rx.computeSignature(def.doctor._id);
      rx.expiresAt = def.expiresAt;
      await rx.save();
    }
    if (def.status === 'DISPENSED') {
      rx.status = 'DISPENSED';
      await rx.save();
    }
    if (def.status === 'EXPIRED') {
      rx.status = 'EXPIRED';
      await rx.save();
    }
    createdRx.push(rx);
  }

  // --- Audit log events ---
  const baseEvents = [
    { actor: admin, eventType: 'USER_LOGIN_SUCCESS', ip: '192.168.1.10' },
    { actor: house, eventType: 'USER_LOGIN_SUCCESS', ip: '192.168.1.20', meta: { mfa: true } },
    { actor: wilson, eventType: 'USER_LOGIN_SUCCESS', ip: '10.0.0.5', meta: { mfa: true } },
    { actor: alice, eventType: 'USER_LOGIN_SUCCESS', ip: '84.237.11.22' },
    { actor: bob, eventType: 'USER_LOGIN_SUCCESS', ip: '84.237.11.25' },
    { actor: house, eventType: 'PRESCRIPTION_CREATED', ip: '192.168.1.20', rt: 'PRESCRIPTION', rid: createdRx[0]._id },
    { actor: house, eventType: 'PRESCRIPTION_SIGNED', ip: '192.168.1.20', rt: 'PRESCRIPTION', rid: createdRx[0]._id },
    { actor: alice, eventType: 'PRESCRIPTION_VIEWED', ip: '84.237.11.22', rt: 'PRESCRIPTION', rid: createdRx[0]._id },
    { actor: house, eventType: 'PRESCRIPTION_CREATED', ip: '192.168.1.20', rt: 'PRESCRIPTION', rid: createdRx[1]._id },
    { actor: wilson, eventType: 'PRESCRIPTION_CREATED', ip: '10.0.0.5', rt: 'PRESCRIPTION', rid: createdRx[2]._id },
    { actor: wilson, eventType: 'PRESCRIPTION_SIGNED', ip: '10.0.0.5', rt: 'PRESCRIPTION', rid: createdRx[2]._id },
    { actor: cuddy, eventType: 'MFA_ENABLED', ip: '192.168.1.30' },
    { actor: alice, eventType: 'USER_PROFILE_UPDATED', ip: '84.237.11.22', rt: 'USER', rid: alice._id },
    { actor: bob, eventType: 'PRESCRIPTION_VIEWED', ip: '84.237.11.25', rt: 'PRESCRIPTION', rid: createdRx[3]._id },
    { actor: admin, eventType: 'ADMIN_USER_CREATED', ip: '192.168.1.10', rt: 'USER', rid: house._id, meta: { role: 'DOCTOR' } },
    { actor: house, eventType: 'PATIENT_VIEWED', ip: '192.168.1.20', rt: 'USER', rid: alice._id },
    { actor: house, eventType: 'PATIENT_VIEWED', ip: '192.168.1.20', rt: 'USER', rid: bob._id },
    { actor: alice, eventType: 'PRESCRIPTION_VIEWED', ip: '84.237.11.22', rt: 'PRESCRIPTION', rid: createdRx[2]._id },
    { actor: house, eventType: 'USER_LOGIN_FAILED', ip: '192.168.1.20', success: false, meta: { reason: 'wrong_password' } },
    { actor: admin, eventType: 'ADMIN_USER_UPDATED', ip: '192.168.1.10', rt: 'USER', rid: carol._id },
  ];

  await AuditLog.create(
    baseEvents.map((e, i) => ({
      actorId: e.actor._id,
      actorEmail: e.actor.email,
      eventType: e.eventType,
      resourceType: e.rt,
      resourceId: e.rid ? String(e.rid) : undefined,
      ipAddress: e.ip,
      metadata: e.meta,
      success: e.success !== false,
      createdAt: new Date(Date.now() - (baseEvents.length - i) * 8 * 60 * 1000),
    }))
  );

  console.log('\n[seed] ✅ done');
  console.log('════════════════════════════════════════════════');
  console.log('  Admin   : admin@medreceipt.io         / Admin!Pass123');
  console.log('  Doctor  : dr.house@medreceipt.io      / Doctor!Pass123  [MFA required]');
  console.log(`               TOTP secret: ${houseTotp.base32}`);
  console.log(`               Current code: ${houseCurrent}`);
  console.log('  Doctor  : dr.wilson@medreceipt.io     / Doctor!Pass123  [MFA required]');
  console.log(`               TOTP secret: ${wilsonTotp.base32}`);
  console.log(`               Current code: ${wilsonCurrent}`);
  console.log('  Doctor  : dr.cuddy@medreceipt.io      / Doctor!Pass123  [no MFA]');
  console.log('  Patient : alice@medreceipt.io          / Patient!Pass123');
  console.log('  Patient : bob@medreceipt.io            / Patient!Pass123');
  console.log('  Patient : carol@medreceipt.io          / Patient!Pass123');
  console.log('  Patient : davis@medreceipt.io          / Patient!Pass123');
  console.log('  Patient : emma@medreceipt.io           / Patient!Pass123');
  console.log('  Patient : frank@medreceipt.io          / Patient!Pass123');
  console.log('════════════════════════════════════════════════\n');

  await mongoose.disconnect();
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
