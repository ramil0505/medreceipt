import { Router } from 'express';
import AuditLog from '../models/AuditLog.js';
import { verifyJWT } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';

const router = Router();

// GET /audit  — admin & doctor; doctor sees only events relating to their actions or their patients' rx
router.get('/', verifyJWT, requireRole('DOCTOR', 'ADMIN'), async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(100, parseInt(req.query.limit) || 30);
  const filter = {};
  if (req.user.role === 'DOCTOR') filter.actorId = req.user.id;
  if (req.query.eventType) filter.eventType = req.query.eventType;
  if (req.query.resourceId) filter.resourceId = req.query.resourceId;
  if (req.query.actorId) filter.actorId = req.query.actorId;

  const [items, total] = await Promise.all([
    AuditLog.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    AuditLog.countDocuments(filter),
  ]);

  // Stats for dashboard
  const stats = await AuditLog.aggregate([
    { $match: filter },
    { $group: { _id: '$eventType', count: { $sum: 1 } } },
    { $sort: { count: -1 } },
    { $limit: 10 },
  ]);

  res.json({
    data: items,
    stats,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
});

export default router;
