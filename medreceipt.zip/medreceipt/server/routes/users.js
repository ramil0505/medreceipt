import { Router } from 'express';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Prescription from '../models/Prescription.js';
import { verifyJWT } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';
import { logEvent } from '../utils/audit.js';

const router = Router();

// GET /users/me
router.get('/me', verifyJWT, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });
  res.json({ data: user.toSafeJSON() });
});

// PUT /users/me
router.put('/me', verifyJWT, async (req, res) => {
  const { fullName, phone, address, emergencyContact, allergies } = req.body;
  const update = {};
  if (typeof fullName === 'string' && fullName.trim().length >= 2) update.fullName = fullName.trim();
  if (typeof phone === 'string' && phone.trim()) update.phone = phone.trim();
  if (typeof address === 'string') update.address = address.trim().slice(0, 500);
  if (typeof emergencyContact === 'string') update.emergencyContact = emergencyContact.trim().slice(0, 200);
  if (typeof allergies === 'string') update.allergies = allergies.trim().slice(0, 1000);

  const user = await User.findByIdAndUpdate(req.user.id, update, { new: true });
  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'USER_PROFILE_UPDATED',
    resourceType: 'USER',
    resourceId: req.user.id,
    req,
  });
  res.json({ data: user.toSafeJSON() });
});

// GET /users — doctors see patients, admin sees all
router.get('/', verifyJWT, requireRole('DOCTOR', 'ADMIN'), async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, parseInt(req.query.limit) || 20);
  const search = (req.query.search || '').trim();
  const role = req.query.role;

  const filter = req.user.role === 'ADMIN'
    ? role ? { role } : {}
    : { role: 'PATIENT' };

  if (req.query.isActive !== undefined) {
    filter.isActive = req.query.isActive === 'true';
  }

  if (search) {
    filter.$or = [
      { fullName: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
      { personalId: { $regex: search, $options: 'i' } },
    ];
  }

  const [items, total] = await Promise.all([
    User.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    User.countDocuments(filter),
  ]);
  res.json({
    data: items.map((u) => u.toSafeJSON()),
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
});

// GET /users/:id — doctor views a patient
router.get('/:id', verifyJWT, requireRole('DOCTOR', 'ADMIN'), async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID', message: 'Invalid user id.' } });
  }
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  const [rxCount, activeCount, recentRx] = await Promise.all([
    Prescription.countDocuments({ patientId: user._id }),
    Prescription.countDocuments({ patientId: user._id, status: 'ACTIVE' }),
    Prescription.find({ patientId: user._id })
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('doctorId', 'fullName specialty'),
  ]);

  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'PATIENT_VIEWED',
    resourceType: 'USER',
    resourceId: user._id,
    req,
  });
  res.json({ data: { ...user.toSafeJSON(), rxCount, activeCount, recentRx } });
});

// PUT /users/:id — Admin updates any user
router.put('/:id', verifyJWT, requireRole('ADMIN'), async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  const { fullName, phone, isActive, specialty, licenseNumber, department, notes } = req.body;
  const update = {};
  if (typeof fullName === 'string' && fullName.trim().length >= 2) update.fullName = fullName.trim();
  if (typeof phone === 'string') update.phone = phone.trim();
  if (typeof isActive === 'boolean') update.isActive = isActive;
  if (typeof specialty === 'string') update.specialty = specialty.trim();
  if (typeof licenseNumber === 'string') update.licenseNumber = licenseNumber.trim();
  if (typeof department === 'string') update.department = department.trim();
  if (typeof notes === 'string') update.notes = notes.trim().slice(0, 2000);

  const user = await User.findByIdAndUpdate(req.params.id, update, { new: true });
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'ADMIN_USER_UPDATED',
    resourceType: 'USER',
    resourceId: user._id,
    metadata: { changes: Object.keys(update) },
    req,
  });
  res.json({ data: user.toSafeJSON() });
});

// POST /users — Admin creates a doctor
router.post('/', verifyJWT, requireRole('ADMIN'), async (req, res) => {
  const { fullName, email, password, personalId, phone, role, licenseNumber, specialty, department } = req.body;
  if (!fullName || !email || !password || !personalId || !phone || !role) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'Missing required fields.' } });
  }
  if (!['DOCTOR', 'PATIENT', 'ADMIN'].includes(role)) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'Invalid role.' } });
  }

  const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{12,}$/;
  if (!PASSWORD_RE.test(password)) {
    return res.status(400).json({ error: { code: 'WEAK_PASSWORD', message: 'Password must be 12+ chars with upper, lower, digit, symbol.' } });
  }

  const existing = await User.findOne({ $or: [{ email }, { personalId }] });
  if (existing) {
    return res.status(409).json({ error: { code: 'CONFLICT', message: 'Email or Personal ID already in use.' } });
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await User.create({
    fullName, email, passwordHash, personalId, phone, role,
    licenseNumber, specialty, department, isVerified: true,
  });

  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'ADMIN_USER_CREATED',
    resourceType: 'USER',
    resourceId: user._id,
    metadata: { role },
    req,
  });
  res.status(201).json({ data: user.toSafeJSON() });
});

// DELETE /users/:id — Admin soft-deletes (deactivates) a user
router.delete('/:id', verifyJWT, requireRole('ADMIN'), async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  if (req.params.id === req.user.id) {
    return res.status(400).json({ error: { code: 'SELF_ACTION', message: 'Cannot deactivate your own account.' } });
  }
  const user = await User.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'ADMIN_USER_DEACTIVATED',
    resourceType: 'USER',
    resourceId: user._id,
    req,
  });
  res.json({ data: { ok: true } });
});

export default router;
