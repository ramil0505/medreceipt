import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import speakeasy from 'speakeasy';
import qrcode from 'qrcode';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import User from '../models/User.js';
import { logEvent } from '../utils/audit.js';
import { verifyJWT, blacklistJti } from '../middleware/auth.js';

const router = Router();

// Rate limit keyed by email (body) so localhost dev isn't affected.
// Falls back to IP only when no email is present (e.g. malformed requests).
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const email = (req.body?.email || '').toLowerCase().trim();
    return email || req.ip;
  },
  skip: (req) => !req.body?.email, // no email → skip limiter, let handler reject it
  message: {
    error: { code: 'RATE_LIMIT', message: 'Too many login attempts for this account. Try again in 15 minutes.' },
  },
});

// Rate limit keyed by the preauthToken subject (userId), not IP.
const mfaLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    try {
      // decode without verifying just to get the sub — full verify happens in the handler
      const raw = req.body?.preauthToken || '';
      const [, payload] = raw.split('.');
      if (!payload) return req.ip;
      const { sub } = JSON.parse(Buffer.from(payload, 'base64url').toString());
      return sub || req.ip;
    } catch {
      return req.ip;
    }
  },
  message: {
    error: { code: 'RATE_LIMIT', message: 'Too many MFA attempts. Try again in 10 minutes.' },
  },
});

const PASSWORD_RE =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{12,}$/;

function tokenLifeFor(role) {
  return role === 'DOCTOR' ? process.env.JWT_DOCTOR_EXPIRY : process.env.JWT_PATIENT_EXPIRY;
}

function expSeconds(remainingMs) {
  return Math.max(1, Math.floor(remainingMs / 1000));
}

function issueToken(user) {
  const jti = crypto.randomUUID();
  const token = jwt.sign(
    { sub: user._id.toString(), role: user.role, email: user.email, jti },
    process.env.JWT_SECRET,
    { expiresIn: tokenLifeFor(user.role) }
  );
  return { token, jti };
}

// POST /auth/register
router.post('/register', async (req, res) => {
  try {
    const { fullName, email, password, personalId, phone, dateOfBirth } = req.body;

    if (!fullName || !email || !password || !personalId || !phone) {
      return res
        .status(400)
        .json({ error: { code: 'BAD_REQUEST', message: 'Missing required fields.' } });
    }
    if (!PASSWORD_RE.test(password)) {
      return res.status(400).json({
        error: {
          code: 'WEAK_PASSWORD',
          message:
            'Password must be at least 12 chars and include uppercase, lowercase, digit, and symbol.',
        },
      });
    }
    const existing = await User.findOne({ $or: [{ email }, { personalId }] });
    if (existing) {
      return res
        .status(409)
        .json({ error: { code: 'CONFLICT', message: 'Account already exists.' } });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({
      fullName,
      email,
      passwordHash,
      personalId,
      phone,
      dateOfBirth,
      role: 'PATIENT',
      isVerified: true,
    });
    await logEvent({
      actorId: user._id,
      actorEmail: user.email,
      eventType: 'USER_REGISTERED',
      resourceType: 'USER',
      resourceId: user._id,
      req,
    });
    return res.status(201).json({ data: user.toSafeJSON() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
});

// POST /auth/login
router.post('/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'Email and password required.' } });
  }
  const user = await User.findOne({ email: String(email).toLowerCase() });
  if (!user) {
    await logEvent({
      eventType: 'USER_LOGIN_FAILED',
      metadata: { email, reason: 'NO_USER' },
      req,
      success: false,
    });
    return res
      .status(401)
      .json({ error: { code: 'INVALID_CREDS', message: 'Invalid email or password.' } });
  }

  if (user.lockoutUntil && user.lockoutUntil > new Date()) {
    const retryAfter = Math.ceil((user.lockoutUntil - new Date()) / 60000);
    return res.status(423).json({
      error: {
        code: 'LOCKED',
        message: `Account locked. Try again in ${retryAfter} minute(s).`,
        retryAfter: user.lockoutUntil.toISOString(),
      },
    });
  }

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    user.failedLoginAttempts += 1;
    if (user.failedLoginAttempts >= 5) {
      user.lockoutUntil = new Date(Date.now() + 15 * 60 * 1000);
      user.failedLoginAttempts = 0;
      await logEvent({
        actorId: user._id,
        actorEmail: user.email,
        eventType: 'ACCOUNT_LOCKED',
        metadata: { reason: 'too_many_failed_attempts' },
        req,
        success: false,
      });
    }
    await user.save();
    await logEvent({
      actorId: user._id,
      actorEmail: user.email,
      eventType: 'USER_LOGIN_FAILED',
      metadata: { attempts: user.failedLoginAttempts },
      req,
      success: false,
    });
    const attemptsLeft = 5 - user.failedLoginAttempts;
    return res.status(401).json({
      error: {
        code: 'INVALID_CREDS',
        message: `Invalid email or password. ${attemptsLeft > 0 ? `${attemptsLeft} attempt(s) remaining.` : 'Account locked.'}`,
      },
    });
  }

  user.failedLoginAttempts = 0;
  user.lockoutUntil = undefined;
  user.lastLoginAt = new Date();
  await user.save();

  if (user.mfaEnabled) {
    const preauth = jwt.sign(
      { sub: user._id.toString(), email: user.email, type: 'preauth' },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_PREAUTH_EXPIRY || '5m' }
    );
    return res.json({
      data: {
        mfaRequired: true,
        preauthToken: preauth,
      },
    });
  }

  const { token } = issueToken(user);
  await logEvent({
    actorId: user._id,
    actorEmail: user.email,
    eventType: 'USER_LOGIN_SUCCESS',
    req,
  });
  return res.json({ data: { token, user: user.toSafeJSON() } });
});

// POST /auth/verify-mfa
router.post('/verify-mfa', mfaLimiter, async (req, res) => {
  const { preauthToken, code } = req.body;
  if (!preauthToken || !code) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'preauthToken and code required.' } });
  }
  let payload;
  try {
    payload = jwt.verify(preauthToken, process.env.JWT_SECRET);
    if (payload.type !== 'preauth') throw new Error('Wrong token type');
  } catch {
    return res
      .status(401)
      .json({ error: { code: 'INVALID_PREAUTH', message: 'Pre-auth token invalid or expired.' } });
  }
  const user = await User.findById(payload.sub);
  if (!user || !user.mfaEnabled || !user.totpSecret) {
    return res
      .status(400)
      .json({ error: { code: 'MFA_NOT_ENABLED', message: 'MFA not configured for this user.' } });
  }

  const cleanCode = String(code).replace(/\s/g, '');
  const verified = speakeasy.totp.verify({
    secret: user.totpSecret,
    encoding: 'base32',
    token: cleanCode,
    window: 2, // allow ±60s clock skew
  });

  if (!verified) {
    await logEvent({
      actorId: user._id,
      actorEmail: user.email,
      eventType: 'MFA_FAILED',
      req,
      success: false,
    });
    return res
      .status(401)
      .json({ error: { code: 'INVALID_MFA', message: 'Invalid or expired MFA code. Check your authenticator app clock.' } });
  }

  const { token } = issueToken(user);
  await logEvent({
    actorId: user._id,
    actorEmail: user.email,
    eventType: 'USER_LOGIN_SUCCESS',
    metadata: { mfa: true },
    req,
  });
  return res.json({ data: { token, user: user.toSafeJSON() } });
});

// POST /auth/mfa/setup — generates a new TOTP secret (requires valid session)
router.post('/mfa/setup', verifyJWT, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  if (user.mfaEnabled) {
    return res.status(400).json({
      error: { code: 'MFA_ALREADY_ENABLED', message: 'MFA is already enabled. Disable it first.' },
    });
  }

  const secret = speakeasy.generateSecret({
    name: `MedReceipt:${user.email}`,
    length: 20,
  });

  // Store pending secret (not yet confirmed)
  user.totpPending = secret.base32;
  await user.save();

  const otpauthUrl = speakeasy.otpauthURL({
    secret: secret.base32,
    label: user.email,           // speakeasy percent-encodes this itself
    issuer: 'MedReceipt',
    encoding: 'base32',
  });

  const qrDataUrl = await qrcode.toDataURL(otpauthUrl);

  return res.json({
    data: {
      secret: secret.base32,
      qrCode: qrDataUrl,
      otpauthUrl,
    },
  });
});

// POST /auth/mfa/confirm — verifies the pending TOTP and activates MFA
router.post('/mfa/confirm', verifyJWT, async (req, res) => {
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'code required.' } });
  }

  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });
  if (!user.totpPending) {
    return res.status(400).json({
      error: { code: 'NO_PENDING_MFA', message: 'Start MFA setup first via POST /auth/mfa/setup.' },
    });
  }

  const cleanCode = String(code).replace(/\s/g, '');
  const verified = speakeasy.totp.verify({
    secret: user.totpPending,
    encoding: 'base32',
    token: cleanCode,
    window: 2,
  });

  if (!verified) {
    return res.status(401).json({
      error: { code: 'INVALID_MFA', message: 'Code incorrect. Try again from your authenticator app.' },
    });
  }

  user.totpSecret = user.totpPending;
  user.totpPending = undefined;
  user.mfaEnabled = true;
  await user.save();

  await logEvent({
    actorId: user._id,
    actorEmail: user.email,
    eventType: 'MFA_ENABLED',
    req,
  });

  return res.json({ data: { ok: true, message: 'MFA enabled successfully.' } });
});

// DELETE /auth/mfa — disables MFA (requires current TOTP or admin)
router.delete('/mfa', verifyJWT, async (req, res) => {
  const { code } = req.body;
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  if (!user.mfaEnabled) {
    return res.status(400).json({ error: { code: 'MFA_NOT_ENABLED', message: 'MFA is not enabled.' } });
  }

  // Require current TOTP to disable (unless admin)
  if (req.user.role !== 'ADMIN') {
    if (!code) {
      return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'Current TOTP code required to disable MFA.' } });
    }
    const cleanCode = String(code).replace(/\s/g, '');
    const verified = speakeasy.totp.verify({
      secret: user.totpSecret,
      encoding: 'base32',
      token: cleanCode,
      window: 2,
    });
    if (!verified) {
      return res.status(401).json({ error: { code: 'INVALID_MFA', message: 'Invalid TOTP code.' } });
    }
  }

  user.mfaEnabled = false;
  user.totpSecret = undefined;
  user.totpPending = undefined;
  await user.save();

  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'MFA_DISABLED',
    resourceType: 'USER',
    resourceId: user._id,
    req,
  });

  return res.json({ data: { ok: true, message: 'MFA disabled.' } });
});

// POST /auth/change-password
router.post('/change-password', verifyJWT, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'currentPassword and newPassword required.' } });
  }
  if (!PASSWORD_RE.test(newPassword)) {
    return res.status(400).json({
      error: { code: 'WEAK_PASSWORD', message: 'Password must be at least 12 chars with uppercase, lowercase, digit, and symbol.' },
    });
  }

  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  const ok = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!ok) {
    return res.status(401).json({ error: { code: 'INVALID_CREDS', message: 'Current password is incorrect.' } });
  }

  if (currentPassword === newPassword) {
    return res.status(400).json({ error: { code: 'SAME_PASSWORD', message: 'New password must differ from current.' } });
  }

  user.passwordHash = await bcrypt.hash(newPassword, 12);
  await user.save();

  await logEvent({
    actorId: user._id,
    actorEmail: user.email,
    eventType: 'PASSWORD_CHANGED',
    req,
  });

  return res.json({ data: { ok: true, message: 'Password updated successfully.' } });
});

// POST /auth/logout
router.post('/logout', verifyJWT, async (req, res) => {
  const remaining = req.user.exp * 1000 - Date.now();
  if (req.user.jti && remaining > 0) blacklistJti(req.user.jti, expSeconds(remaining));
  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'USER_LOGOUT',
    req,
  });
  return res.json({ data: { ok: true } });
});

// GET /auth/me
router.get('/me', verifyJWT, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });
  return res.json({ data: user.toSafeJSON() });
});

export default router;
// ─── Forgot / Reset password (token-based, no email server needed in dev) ────

// POST /auth/forgot-password
// In production this would email a link; in dev we return the token directly.
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'Email required.' } });
  }

  const user = await User.findOne({ email: String(email).toLowerCase() });

  // Always respond the same way to prevent user enumeration
  const GENERIC_OK = { data: { ok: true, message: 'If that email exists, a reset link has been sent.' } };

  if (!user) return res.json(GENERIC_OK);

  // Generate a signed, short-lived reset token (15 min)
  const resetToken = jwt.sign(
    { sub: user._id.toString(), email: user.email, type: 'password-reset' },
    process.env.JWT_SECRET,
    { expiresIn: '15m' }
  );

  // In production: send email with link containing resetToken.
  // In dev: return the token directly so it can be used without an SMTP server.
  const isDev = process.env.NODE_ENV !== 'production';

  await logEvent({
    actorId: user._id,
    actorEmail: user.email,
    eventType: 'PASSWORD_RESET_REQUESTED',
    req,
  });

  return res.json({
    data: {
      ok: true,
      message: isDev
        ? 'Dev mode: use the resetToken below to reset your password.'
        : 'If that email exists, a reset link has been sent.',
      ...(isDev && { resetToken }),
    },
  });
});

// POST /auth/reset-password
router.post('/reset-password', async (req, res) => {
  const { resetToken, newPassword } = req.body;
  if (!resetToken || !newPassword) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'resetToken and newPassword required.' } });
  }

  const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{12,}$/;
  if (!PASSWORD_RE.test(newPassword)) {
    return res.status(400).json({
      error: { code: 'WEAK_PASSWORD', message: 'Password must be 12+ chars with upper, lower, digit, and symbol.' },
    });
  }

  let payload;
  try {
    payload = jwt.verify(resetToken, process.env.JWT_SECRET);
    if (payload.type !== 'password-reset') throw new Error('Wrong token type');
  } catch {
    return res.status(401).json({ error: { code: 'INVALID_TOKEN', message: 'Reset link invalid or expired.' } });
  }

  const user = await User.findById(payload.sub);
  if (!user) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  user.passwordHash = await bcrypt.hash(newPassword, 12);
  user.failedLoginAttempts = 0;
  user.lockoutUntil = undefined;
  user.passwordChangedAt = new Date();
  await user.save();

  await logEvent({
    actorId: user._id,
    actorEmail: user.email,
    eventType: 'PASSWORD_RESET_COMPLETED',
    req,
  });

  return res.json({ data: { ok: true, message: 'Password reset successfully. You can now log in.' } });
});

