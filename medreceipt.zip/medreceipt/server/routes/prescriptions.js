import { Router } from 'express';
import mongoose from 'mongoose';
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';
import Prescription from '../models/Prescription.js';
import User from '../models/User.js';
import { verifyJWT } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';
import { logEvent } from '../utils/audit.js';

const router = Router();

// GET /prescriptions  — doctors see all theirs, patients see their own (JWT-injected)
router.get('/', verifyJWT, async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, parseInt(req.query.limit) || 20);

  let filter = {};
  if (req.user.role === 'PATIENT') {
    // IDOR protection — server derives patientId from JWT, never trusts the client
    filter.patientId = req.user.id;
  } else if (req.user.role === 'DOCTOR') {
    if (req.query.patientId && mongoose.isValidObjectId(req.query.patientId)) {
      filter.patientId = req.query.patientId;
    } else {
      filter.doctorId = req.user.id;
    }
  }
  if (req.query.status) filter.status = req.query.status;

  const [items, total] = await Promise.all([
    Prescription.find(filter)
      .populate('patientId', 'fullName email personalId')
      .populate('doctorId', 'fullName licenseNumber specialty')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    Prescription.countDocuments(filter),
  ]);
  res.json({
    data: items,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
});

// GET /prescriptions/:id — ownership enforced server-side
router.get('/:id', verifyJWT, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  const rx = await Prescription.findById(req.params.id)
    .populate('patientId', 'fullName email personalId phone dateOfBirth')
    .populate('doctorId', 'fullName licenseNumber specialty');
  if (!rx) return res.status(404).json({ error: { code: 'NOT_FOUND' } });

  // IDOR: patients can only read their own
  if (req.user.role === 'PATIENT' && String(rx.patientId._id) !== String(req.user.id)) {
    await logEvent({
      actorId: req.user.id,
      actorEmail: req.user.email,
      eventType: 'IDOR_ATTEMPT',
      resourceType: 'PRESCRIPTION',
      resourceId: rx._id,
      req,
      success: false,
    });
    return res.status(403).json({
      error: { code: 'FORBIDDEN', message: 'You do not have access to this prescription.' },
    });
  }
  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'PRESCRIPTION_VIEWED',
    resourceType: 'PRESCRIPTION',
    resourceId: rx._id,
    req,
  });
  res.json({ data: rx });
});

// POST /prescriptions  (Doctor only)
router.post('/', verifyJWT, requireRole('DOCTOR'), async (req, res) => {
  const { patientId, diagnosis, medication, dosage, instructions } = req.body;
  if (!patientId || !diagnosis || !medication || !dosage || !instructions) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'All clinical fields are required.' } });
  }
  if (!mongoose.isValidObjectId(patientId)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  const patient = await User.findById(patientId);
  if (!patient || patient.role !== 'PATIENT') {
    return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Patient not found.' } });
  }
  const rx = await Prescription.create({
    patientId,
    doctorId: req.user.id,
    diagnosis: String(diagnosis).slice(0, 5000),
    medication: String(medication).slice(0, 500),
    dosage: String(dosage).slice(0, 200),
    instructions: String(instructions).slice(0, 5000),
    status: 'DRAFT',
  });
  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'PRESCRIPTION_CREATED',
    resourceType: 'PRESCRIPTION',
    resourceId: rx._id,
    req,
  });
  res.status(201).json({ data: rx });
});

// PUT /prescriptions/:id/sign  (Doctor only — DRAFT → ACTIVE)
router.put('/:id/sign', verifyJWT, requireRole('DOCTOR'), async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  const rx = await Prescription.findById(req.params.id);
  if (!rx) return res.status(404).json({ error: { code: 'NOT_FOUND' } });
  if (String(rx.doctorId) !== String(req.user.id)) {
    return res.status(403).json({
      error: {
        code: 'FORBIDDEN',
        message: 'Only the prescribing doctor can sign this prescription.',
      },
    });
  }
  if (rx.status !== 'DRAFT') {
    return res
      .status(409)
      .json({ error: { code: 'BAD_STATE', message: 'Only DRAFT prescriptions can be signed.' } });
  }
  rx.status = 'ACTIVE';
  rx.signedAt = new Date();
  rx.signatureHash = rx.computeSignature(req.user.id);
  rx.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
  await rx.save();
  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'PRESCRIPTION_SIGNED',
    resourceType: 'PRESCRIPTION',
    resourceId: rx._id,
    req,
  });
  res.json({ data: rx });
});

// PUT /prescriptions/:id/status  (Doctor only — ACTIVE → DISPENSED → EXPIRED)
router.put('/:id/status', verifyJWT, requireRole('DOCTOR', 'ADMIN'), async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  const { status } = req.body;
  const validForward = {
    ACTIVE: ['DISPENSED', 'EXPIRED'],
    DISPENSED: ['EXPIRED'],
  };
  const rx = await Prescription.findById(req.params.id);
  if (!rx) return res.status(404).json({ error: { code: 'NOT_FOUND' } });
  if (!validForward[rx.status]?.includes(status)) {
    return res.status(409).json({
      error: { code: 'BAD_STATE', message: `Cannot transition from ${rx.status} to ${status}.` },
    });
  }
  rx.status = status;
  await rx.save();
  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: `PRESCRIPTION_${status}`,
    resourceType: 'PRESCRIPTION',
    resourceId: rx._id,
    req,
  });
  res.json({ data: rx });
});

// GET /prescriptions/:id/pdf  — streams a PDF with QR code
router.get('/:id/pdf', verifyJWT, async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ error: { code: 'BAD_ID' } });
  }
  const rx = await Prescription.findById(req.params.id)
    .populate('patientId', 'fullName personalId dateOfBirth phone')
    .populate('doctorId', 'fullName licenseNumber specialty');
  if (!rx) return res.status(404).json({ error: { code: 'NOT_FOUND' } });
  if (req.user.role === 'PATIENT' && String(rx.patientId._id) !== String(req.user.id)) {
    return res.status(403).json({ error: { code: 'FORBIDDEN' } });
  }
  if (rx.status === 'DRAFT') {
    return res
      .status(409)
      .json({ error: { code: 'BAD_STATE', message: 'PDF available only after signing.' } });
  }

  const qrPayload = JSON.stringify({
    id: rx._id,
    sig: rx.signatureHash?.slice(0, 16),
  });
  const qrDataUrl = await QRCode.toDataURL(qrPayload, { margin: 1, width: 160 });
  const qrBuffer = Buffer.from(qrDataUrl.split(',')[1], 'base64');

  await logEvent({
    actorId: req.user.id,
    actorEmail: req.user.email,
    eventType: 'PRESCRIPTION_DOWNLOADED',
    resourceType: 'PRESCRIPTION',
    resourceId: rx._id,
    req,
  });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `inline; filename="prescription-${rx._id}.pdf"`
  );

  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  doc.pipe(res);

  // Header
  doc
    .fontSize(20)
    .fillColor('#0F3D2E')
    .text('MedReceipt', { align: 'left' })
    .fontSize(10)
    .fillColor('#666')
    .text('Digital Prescription', { align: 'left' })
    .moveDown(0.5);

  doc
    .moveTo(50, doc.y)
    .lineTo(545, doc.y)
    .strokeColor('#0F3D2E')
    .lineWidth(1.5)
    .stroke()
    .moveDown();

  // Patient & doctor
  const startY = doc.y;
  doc
    .fontSize(9)
    .fillColor('#666')
    .text('PATIENT', 50, startY)
    .fontSize(11)
    .fillColor('#111')
    .text(rx.patientId.fullName, 50, startY + 14);
  doc
    .fontSize(9)
    .fillColor('#666')
    .text(`ID: ${rx.patientId.personalId}`, 50, startY + 32);

  doc
    .fontSize(9)
    .fillColor('#666')
    .text('PRESCRIBING DOCTOR', 320, startY)
    .fontSize(11)
    .fillColor('#111')
    .text(rx.doctorId.fullName, 320, startY + 14);
  doc
    .fontSize(9)
    .fillColor('#666')
    .text(
      `Lic: ${rx.doctorId.licenseNumber || '—'} · ${rx.doctorId.specialty || ''}`,
      320,
      startY + 32
    );

  doc.moveDown(3);

  // Clinical details
  const block = (label, value) => {
    doc
      .fontSize(9)
      .fillColor('#666')
      .text(label.toUpperCase())
      .moveDown(0.2)
      .fontSize(11)
      .fillColor('#111')
      .text(value, { width: 495 })
      .moveDown(0.8);
  };
  block('Diagnosis', rx.diagnosis);
  block('Medication', rx.medication);
  block('Dosage', rx.dosage);
  block('Instructions', rx.instructions);

  // QR + meta
  doc.image(qrBuffer, 50, 700, { width: 90 });
  doc
    .fontSize(8)
    .fillColor('#666')
    .text(`Prescription ID: ${rx._id}`, 160, 710)
    .text(`Status: ${rx.status}`, 160, 722)
    .text(
      `Signed: ${rx.signedAt ? new Date(rx.signedAt).toISOString().slice(0, 19) : '—'}`,
      160,
      734
    )
    .text(
      `Expires: ${rx.expiresAt ? new Date(rx.expiresAt).toISOString().slice(0, 10) : '—'}`,
      160,
      746
    )
    .text(`Signature: ${rx.signatureHash || '—'}`, 160, 758, { width: 380 });

  doc.end();
});

export default router;
