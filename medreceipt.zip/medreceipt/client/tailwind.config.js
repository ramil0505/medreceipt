/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['Fraunces', 'Georgia', 'serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      colors: {
        paper: {
          50: '#FBFAF6',
          100: '#F6F4EC',
          200: '#EDEAE0',
          300: '#DFDBCC',
        },
        ink: {
          900: '#16140F',
          800: '#23211B',
          700: '#3A372F',
          600: '#5A564A',
          500: '#7B7665',
          400: '#A09B89',
        },
        forest: {
          50: '#EAF1ED',
          100: '#CDDDD3',
          300: '#7BA38C',
          500: '#3F7458',
          600: '#2F5C44',
          700: '#214432',
          800: '#163024',
          900: '#0F2018',
        },
        rust: {
          400: '#C97A4A',
          500: '#A75E33',
          600: '#854726',
        },
        gold: {
          400: '#C8A24A',
          500: '#A8862F',
        },
      },
      boxShadow: {
        soft: '0 1px 2px rgba(22, 20, 15, 0.04), 0 4px 16px rgba(22, 20, 15, 0.06)',
        ring: '0 0 0 1px rgba(22, 20, 15, 0.08)',
        'ring-strong': '0 0 0 1px rgba(22, 20, 15, 0.16)',
      },
      backgroundImage: {
        grain:
          "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' /%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")",
      },
      letterSpacing: {
        tightest: '-0.04em',
      },
    },
  },
  plugins: [],
};
