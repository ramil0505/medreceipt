import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate, Navigate } from 'react-router-dom';
import { ShieldCheck, ArrowRight, RefreshCw, AlertTriangle } from 'lucide-react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function MfaVerify() {
  const location = useLocation();
  const navigate = useNavigate();
  const { finishLogin } = useAuth();
  const preauthToken = location.state?.preauthToken;
  const email = location.state?.email;

  const [digits, setDigits] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);
  const refs = useRef([]);

  useEffect(() => { refs.current[0]?.focus(); }, []);

  if (!preauthToken) return <Navigate to="/login" replace />;

  const setDigit = (i, v) => {
    if (!/^\d?$/.test(v)) return;
    const next = [...digits];
    next[i] = v;
    setDigits(next);
    if (v && i < 5) refs.current[i + 1]?.focus();
    // Auto-submit when last digit filled
    if (v && i === 5) {
      const full = [...next].join('');
      if (full.length === 6) setTimeout(() => submitCode(full), 80);
    }
  };

  const onKey = (i, e) => {
    if (e.key === 'Backspace' && !digits[i] && i > 0) refs.current[i - 1]?.focus();
    if (e.key === 'Enter') {
      const code = digits.join('');
      if (code.length === 6) submitCode(code);
    }
  };

  const onPaste = (e) => {
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!text) return;
    e.preventDefault();
    const arr = [...digits];
    for (let i = 0; i < 6; i++) arr[i] = text[i] || '';
    setDigits(arr);
    refs.current[Math.min(text.length, 5)]?.focus();
    if (text.length === 6) setTimeout(() => submitCode(text), 80);
  };

  const submitCode = async (code) => {
    if (loading) return;
    setLoading(true);
    setError('');
    try {
      const r = await api.post('/auth/verify-mfa', { preauthToken, code });
      finishLogin(r.data.data);
      navigate('/');
    } catch (err) {
      const msg = err.response?.data?.error?.message || 'Verification failed.';
      setError(msg);
      setAttempts(a => a + 1);
      // Clear digits on error for re-entry
      setDigits(['', '', '', '', '', '']);
      setTimeout(() => refs.current[0]?.focus(), 50);
    } finally {
      setLoading(false);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    const code = digits.join('');
    if (code.length !== 6) return setError('Enter the full 6-digit code.');
    submitCode(code);
  };

  const filledCount = digits.filter(Boolean).length;

  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-paper-50">
      <div className="w-full max-w-md">
        <div className="panel p-10 fade-up">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
              <ShieldCheck size={20} strokeWidth={1.5} />
            </div>
            <div>
              <div className="label-eyebrow">§ 01·b — Two-factor authentication</div>
              <div className="text-sm text-ink-700 font-medium">{email}</div>
            </div>
          </div>

          <h1 className="display-serif text-4xl text-ink-900 mb-2 leading-none">
            Enter your code.
          </h1>
          <p className="text-sm text-ink-600 mb-8">
            Open your authenticator app and enter the 6-digit code for MedReceipt.
            Codes refresh every 30 seconds.
          </p>

          <form onSubmit={submit}>
            <div className="flex gap-2 justify-between" onPaste={onPaste}>
              {digits.map((d, i) => (
                <input
                  key={i}
                  ref={(el) => (refs.current[i] = el)}
                  inputMode="numeric"
                  maxLength={1}
                  value={d}
                  onChange={(e) => setDigit(i, e.target.value)}
                  onKeyDown={(e) => onKey(i, e)}
                  disabled={loading}
                  className={`w-12 h-14 text-center text-2xl font-mono border rounded-xl
                    transition-colors focus:outline-none focus:ring-4
                    ${d ? 'bg-forest-50 border-forest-300 text-forest-900' : 'bg-paper-50 border-ink-900/10 text-ink-900'}
                    focus:border-forest-700 focus:ring-forest-700/10
                    disabled:opacity-60`}
                />
              ))}
            </div>

            {/* Progress indicator */}
            <div className="flex gap-1 mt-3">
              {digits.map((d, i) => (
                <div key={i} className={`h-0.5 flex-1 rounded-full transition-colors ${d ? 'bg-forest-600' : 'bg-ink-200'}`} />
              ))}
            </div>

            {error && (
              <div className="text-rust-600 text-sm bg-rust-50 border border-rust-200 rounded-xl px-4 py-3 mt-5 flex items-start gap-2">
                <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {attempts >= 3 && (
              <div className="text-amber-700 text-xs bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 mt-3">
                Having trouble? Make sure your device clock is accurate, or try generating a fresh code.
              </div>
            )}

            <button
              type="submit"
              disabled={loading || filledCount < 6}
              className="btn-primary w-full mt-6"
            >
              {loading ? (
                <><RefreshCw size={16} className="animate-spin" />Verifying…</>
              ) : (
                <>Verify and continue<ArrowRight size={16} /></>
              )}
            </button>

            <button
              type="button"
              onClick={() => navigate('/login')}
              className="btn-ghost w-full mt-2 text-sm"
            >
              ← Back to login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
