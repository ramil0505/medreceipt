import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Plus, Mail, Phone, Fingerprint, Calendar, ArrowRight } from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import Modal from '../components/ui/Modal.jsx';

export default function PatientDetail() {
  const { id } = useParams();
  const [patient, setPatient] = useState(null);
  const [rxs, setRxs] = useState([]);
  const [open, setOpen] = useState(false);

  const reload = async () => {
    const [p, r] = await Promise.all([
      api.get(`/users/${id}`),
      api.get(`/prescriptions?patientId=${id}&limit=50`),
    ]);
    setPatient(p.data.data);
    setRxs(r.data.data);
  };

  useEffect(() => {
    reload();
  }, [id]);

  if (!patient) return <Layout title="Loading…" />;

  return (
    <Layout
      eyebrow="Patient file"
      title={
        <>
          {patient.fullName.split(' ')[0]}{' '}
          <em className="font-extralight italic">{patient.fullName.split(' ').slice(1).join(' ')}</em>
        </>
      }
      action={
        <button onClick={() => setOpen(true)} className="btn-primary">
          <Plus size={16} /> New prescription
        </button>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6">
        {/* Profile card */}
        <div className="panel p-6 self-start">
          <div className="w-16 h-16 rounded-2xl bg-forest-700 text-paper-50 flex items-center justify-center display-serif text-2xl mb-4">
            {patient.fullName.split(' ').map((s) => s[0]).slice(0, 2).join('')}
          </div>
          <div className="display-serif text-2xl text-ink-900 leading-tight">
            {patient.fullName}
          </div>
          <div className="label-eyebrow mt-1">Patient · ID {patient.personalId}</div>

          <div className="mt-6 space-y-3">
            <Field icon={Mail} label="Email" value={patient.email} />
            <Field icon={Phone} label="Phone" value={patient.phone} />
            <Field icon={Fingerprint} label="Personal ID" value={patient.personalId} mono />
            {patient.dateOfBirth && (
              <Field
                icon={Calendar}
                label="Date of birth"
                value={new Date(patient.dateOfBirth).toLocaleDateString()}
              />
            )}
          </div>

          <div className="divider-soft my-6" />

          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="display-serif text-3xl text-ink-900">{patient.rxCount ?? 0}</div>
              <div className="label-eyebrow mt-1">Total Rx</div>
            </div>
            <div>
              <div className="display-serif text-3xl text-forest-700">
                {patient.activeCount ?? 0}
              </div>
              <div className="label-eyebrow mt-1">Active</div>
            </div>
          </div>
        </div>

        {/* Rx history */}
        <div className="panel">
          <div className="flex items-center justify-between px-6 pt-5 pb-3">
            <div>
              <div className="label-eyebrow mb-1">Prescription history</div>
              <div className="display-serif text-2xl">All records</div>
            </div>
            <div className="text-xs text-ink-500">{rxs.length} entries</div>
          </div>
          <div className="divider-soft" />
          <div className="divide-y divide-ink-900/[0.05]">
            {rxs.length === 0 && (
              <div className="px-6 py-12 text-center">
                <div className="text-sm text-ink-500 mb-3">
                  No prescriptions on file for this patient.
                </div>
                <button onClick={() => setOpen(true)} className="btn-secondary">
                  Write the first one <ArrowRight size={14} />
                </button>
              </div>
            )}
            {rxs.map((rx, i) => (
              <Link
                to={`/prescriptions/${rx._id}`}
                key={rx._id}
                className="grid grid-cols-[1fr_auto_auto] gap-4 items-center px-6 py-4 hover:bg-paper-100/60 transition fade-up"
                style={{ animationDelay: `${Math.min(i * 30, 300)}ms` }}
              >
                <div className="min-w-0">
                  <div className="text-sm text-ink-900 truncate">{rx.medication}</div>
                  <div className="text-xs text-ink-500 mt-0.5 truncate">
                    {rx.diagnosis} · {rx.dosage}
                  </div>
                </div>
                <StatusBadge status={rx.status} />
                <div className="text-xs text-ink-500 hidden md:block">
                  {new Date(rx.createdAt).toLocaleDateString()}
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <CreatePrescriptionModal
        open={open}
        onClose={() => setOpen(false)}
        patientId={id}
        onCreated={() => {
          setOpen(false);
          reload();
        }}
      />
    </Layout>
  );
}

function Field({ icon: Icon, label, value, mono }) {
  return (
    <div className="flex items-start gap-3">
      <Icon size={14} className="text-ink-500 mt-0.5" />
      <div className="min-w-0">
        <div className="label-eyebrow">{label}</div>
        <div className={`text-sm text-ink-800 truncate ${mono ? 'font-mono' : ''}`}>{value}</div>
      </div>
    </div>
  );
}

function CreatePrescriptionModal({ open, onClose, patientId, onCreated }) {
  const [form, setForm] = useState({
    diagnosis: '',
    medication: '',
    dosage: '',
    instructions: '',
  });
  const [step, setStep] = useState('write'); // write | sign
  const [created, setCreated] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setForm({ diagnosis: '', medication: '', dosage: '', instructions: '' });
      setStep('write');
      setCreated(null);
      setError('');
    }
  }, [open]);

  const ch = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const r = await api.post('/prescriptions', { patientId, ...form });
      setCreated(r.data.data);
      setStep('sign');
    } catch (err) {
      setError(err.response?.data?.error?.message || 'Failed to create.');
    } finally {
      setLoading(false);
    }
  };

  const sign = async () => {
    setLoading(true);
    setError('');
    try {
      await api.put(`/prescriptions/${created._id}/sign`);
      onCreated();
    } catch (err) {
      setError(err.response?.data?.error?.message || 'Failed to sign.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      subtitle={step === 'write' ? '§ A — Compose' : '§ B — Sign and finalise'}
      title={step === 'write' ? 'New prescription' : 'Confirm and sign'}
      size="lg"
    >
      {step === 'write' && (
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="field-label">Diagnosis</label>
            <input
              className="input"
              value={form.diagnosis}
              onChange={ch('diagnosis')}
              placeholder="e.g. Acute bacterial sinusitis"
              required
            />
          </div>
          <div>
            <label className="field-label">Medication</label>
            <input
              className="input"
              value={form.medication}
              onChange={ch('medication')}
              placeholder="e.g. Amoxicillin 500 mg capsules"
              required
            />
          </div>
          <div>
            <label className="field-label">Dosage</label>
            <input
              className="input"
              value={form.dosage}
              onChange={ch('dosage')}
              placeholder="e.g. 1 capsule three times daily"
              required
            />
          </div>
          <div>
            <label className="field-label">Instructions</label>
            <textarea
              className="input min-h-[100px] resize-y"
              value={form.instructions}
              onChange={ch('instructions')}
              placeholder="Special instructions for the patient…"
              required
            />
          </div>
          {error && (
            <div className="text-rust-500 text-sm bg-rust-400/10 border border-rust-400/20 rounded-xl px-4 py-2.5">
              {error}
            </div>
          )}
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="btn-ghost">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn-primary">
              {loading ? 'Saving draft…' : 'Save draft & review'}
              <ArrowRight size={14} />
            </button>
          </div>
        </form>
      )}
      {step === 'sign' && created && (
        <div>
          <div className="panel-flat p-5 mb-4 space-y-2.5">
            <Row label="Diagnosis" value={created.diagnosis} />
            <Row label="Medication" value={created.medication} />
            <Row label="Dosage" value={created.dosage} />
            <Row label="Instructions" value={created.instructions} />
          </div>
          <div className="text-xs text-ink-600 bg-forest-50 border border-forest-100 rounded-xl px-4 py-3 mb-4">
            Signing this prescription is{' '}
            <span className="font-medium text-forest-800">irreversible</span>: medical content
            becomes immutable, an e-signature is computed and attached, and the patient is
            notified. The status will transition from DRAFT to ACTIVE.
          </div>
          {error && (
            <div className="text-rust-500 text-sm bg-rust-400/10 border border-rust-400/20 rounded-xl px-4 py-2.5 mb-3">
              {error}
            </div>
          )}
          <div className="flex justify-end gap-2">
            <button onClick={() => setStep('write')} className="btn-ghost">
              Edit draft
            </button>
            <button onClick={sign} disabled={loading} className="btn-primary">
              {loading ? 'Signing…' : 'Sign & activate'}
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}

function Row({ label, value }) {
  return (
    <div className="grid grid-cols-[120px_1fr] gap-3 text-sm">
      <div className="label-eyebrow self-start mt-0.5">{label}</div>
      <div className="text-ink-800">{value}</div>
    </div>
  );
}
