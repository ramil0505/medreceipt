import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  Stethoscope,
  FileText,
  ShieldAlert,
  Activity,
  ArrowUpRight,
  TrendingUp,
  ScrollText,
  CheckCircle2,
  AlertTriangle,
  Clock,
} from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import StatusBadge from '../components/StatusBadge.jsx';

const eventLabel = {
  USER_LOGIN_SUCCESS: 'Login success',
  USER_LOGIN_FAIL: 'Login failure',
  USER_LOGOUT: 'Logout',
  USER_REGISTERED: 'Registration',
  MFA_VERIFIED: 'MFA verified',
  PRESCRIPTION_CREATED: 'Prescription created',
  PRESCRIPTION_SIGNED: 'Prescription signed',
  PRESCRIPTION_VIEWED: 'Prescription viewed',
  PRESCRIPTION_DOWNLOADED: 'PDF downloaded',
  PRESCRIPTION_STATUS_CHANGED: 'Status changed',
  PATIENT_VIEWED: 'Patient viewed',
  IDOR_ATTEMPT: 'IDOR attempt',
  ACCOUNT_LOCKED: 'Account locked',
};

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function StatCard({ label, value, sub, icon: Icon, accent = 'forest', delay = 0 }) {
  const accentMap = {
    forest: 'text-forest-700 bg-forest-50',
    gold: 'text-gold-700 bg-gold-50',
    rust: 'text-rust-700 bg-rust-50',
    ink: 'text-ink-700 bg-ink-100',
  };
  return (
    <div
      className="panel p-6 fade-up flex flex-col justify-between min-h-[148px]"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between">
        <div className="label-eyebrow text-ink-500">{label}</div>
        <div className={`h-8 w-8 rounded-md flex items-center justify-center ${accentMap[accent]}`}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div>
        <div className="display-serif text-5xl text-ink-900 leading-none mb-1">{value}</div>
        {sub && <div className="text-xs text-ink-500">{sub}</div>}
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [rxStats, setRxStats] = useState({ total: 0, active: 0, draft: 0, dispensed: 0 });
  const [recentRx, setRecentRx] = useState([]);
  const [auditEvents, setAuditEvents] = useState([]);
  const [auditStats, setAuditStats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const [uRes, rxRes, aRes] = await Promise.all([
          api.get('/users', { params: { limit: 200 } }).catch(() => ({ data: { data: [] } })),
          api.get('/prescriptions', { params: { limit: 50 } }).catch(() => ({ data: { data: [] } })),
          api.get('/audit-log', { params: { limit: 25 } }).catch(() => ({ data: { data: [], stats: [] } })),
        ]);
        if (ignore) return;
        const allUsers = uRes.data.data || [];
        const rxList = rxRes.data.data || [];
        setUsers(allUsers);
        setRecentRx(rxList.slice(0, 6));
        setRxStats({
          total: rxList.length,
          active: rxList.filter((r) => r.status === 'ACTIVE').length,
          draft: rxList.filter((r) => r.status === 'DRAFT').length,
          dispensed: rxList.filter((r) => r.status === 'DISPENSED').length,
        });
        setAuditEvents(aRes.data.data || []);
        setAuditStats(aRes.data.stats || []);
      } finally {
        if (!ignore) setLoading(false);
      }
    })();
    return () => {
      ignore = true;
    };
  }, []);

  const doctorCount = users.filter((u) => u.role === 'DOCTOR').length;
  const patientCount = users.filter((u) => u.role === 'PATIENT').length;
  const adminCount = users.filter((u) => u.role === 'ADMIN').length;

  const securityEvents = auditEvents.filter((e) =>
    ['IDOR_ATTEMPT', 'USER_LOGIN_FAIL', 'ACCOUNT_LOCKED'].includes(e.eventType)
  );

  const topEventTypes = [...auditStats]
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  return (
    <Layout
      eyebrow="Operator console"
      title="Operations overview"
      action={
        <Link to="/audit" className="btn-secondary">
          <ScrollText className="h-4 w-4" />
          Full audit trail
          <ArrowUpRight className="h-3.5 w-3.5" />
        </Link>
      }
    >
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <StatCard
          label="Patients"
          value={loading ? '—' : patientCount}
          sub="Registered accounts"
          icon={Users}
          delay={0}
        />
        <StatCard
          label="Physicians"
          value={loading ? '—' : doctorCount}
          sub="Authorised prescribers"
          icon={Stethoscope}
          accent="ink"
          delay={60}
        />
        <StatCard
          label="Active Rx"
          value={loading ? '—' : rxStats.active}
          sub={`${rxStats.total} total in system`}
          icon={FileText}
          accent="forest"
          delay={120}
        />
        <StatCard
          label="Security flags"
          value={loading ? '—' : securityEvents.length}
          sub="In recent activity"
          icon={ShieldAlert}
          accent={securityEvents.length > 0 ? 'rust' : 'forest'}
          delay={180}
        />
      </div>

      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-6">
        {/* LEFT — system health + recent rx */}
        <div className="space-y-6">
          {/* System health */}
          <section className="panel p-7">
            <div className="flex items-end justify-between mb-6">
              <div>
                <div className="label-eyebrow mb-1">Indicators</div>
                <h2 className="display-serif text-2xl text-ink-900">System health</h2>
              </div>
              <div className="flex items-center gap-2 text-xs text-forest-700">
                <span className="h-2 w-2 rounded-full bg-forest-600 animate-pulse" />
                Operational
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <HealthRow icon={CheckCircle2} status="ok" label="API gateway" detail="All endpoints responding" />
              <HealthRow icon={CheckCircle2} status="ok" label="MongoDB" detail="Local connection healthy" />
              <HealthRow icon={CheckCircle2} status="ok" label="Audit pipeline" detail="Append-only, integrity verified" />
              <HealthRow icon={CheckCircle2} status="ok" label="JWT issuer" detail="Tokens signing & validating" />
              <HealthRow icon={CheckCircle2} status="ok" label="Rate limiter" detail="5 attempts / 15 min" />
              <HealthRow
                icon={securityEvents.length > 0 ? AlertTriangle : CheckCircle2}
                status={securityEvents.length > 0 ? 'warn' : 'ok'}
                label="Threat surface"
                detail={
                  securityEvents.length > 0
                    ? `${securityEvents.length} flagged event${securityEvents.length === 1 ? '' : 's'}`
                    : 'No anomalies detected'
                }
              />
            </div>
          </section>

          {/* Recent prescriptions */}
          <section className="panel p-7">
            <div className="flex items-end justify-between mb-6">
              <div>
                <div className="label-eyebrow mb-1">Recent</div>
                <h2 className="display-serif text-2xl text-ink-900">Prescription activity</h2>
              </div>
              <Link to="/audit" className="text-xs text-forest-700 hover:text-forest-900 flex items-center gap-1">
                See all <ArrowUpRight className="h-3 w-3" />
              </Link>
            </div>

            {loading ? (
              <div className="text-sm text-ink-400">Loading…</div>
            ) : recentRx.length === 0 ? (
              <div className="text-sm text-ink-400 py-6">No prescriptions yet.</div>
            ) : (
              <ul className="divide-y divide-ink-100">
                {recentRx.map((rx) => (
                  <li key={rx.id} className="py-3 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-ink-900 font-medium truncate">
                        {rx.medication}
                      </div>
                      <div className="text-xs text-ink-500 mt-0.5 flex items-center gap-2">
                        <span className="truncate">{rx.patient?.fullName || '—'}</span>
                        <span className="text-ink-300">•</span>
                        <span className="truncate">Dr. {rx.doctor?.fullName?.split(' ').slice(-1)[0] || '—'}</span>
                      </div>
                    </div>
                    <StatusBadge status={rx.status} />
                    <div className="text-xs text-ink-400 w-16 text-right tabular-nums">
                      {timeAgo(rx.createdAt)}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        {/* RIGHT — population + activity feed */}
        <div className="space-y-6">
          {/* Population breakdown */}
          <section className="panel p-7">
            <div className="label-eyebrow mb-1">Population</div>
            <h2 className="display-serif text-2xl text-ink-900 mb-5">User base</h2>

            <PopulationBar
              label="Patients"
              count={patientCount}
              total={users.length}
              color="bg-forest-600"
            />
            <PopulationBar
              label="Physicians"
              count={doctorCount}
              total={users.length}
              color="bg-ink-700"
            />
            <PopulationBar
              label="Operators"
              count={adminCount}
              total={users.length}
              color="bg-gold-500"
            />

            <Link
              to="/admin/users"
              className="mt-5 pt-5 border-t border-ink-100 flex items-center justify-between text-sm text-forest-700 hover:text-forest-900"
            >
              <span>Manage users</span>
              <ArrowUpRight className="h-4 w-4" />
            </Link>
          </section>

          {/* Top events */}
          <section className="panel p-7">
            <div className="label-eyebrow mb-1">Last 24h</div>
            <h2 className="display-serif text-2xl text-ink-900 mb-5">Top events</h2>

            {topEventTypes.length === 0 ? (
              <div className="text-sm text-ink-400 py-3">No events recorded.</div>
            ) : (
              <ul className="space-y-2.5">
                {topEventTypes.map((s) => {
                  const max = topEventTypes[0].count || 1;
                  const w = Math.max(8, (s.count / max) * 100);
                  return (
                    <li key={s.eventType} className="text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-ink-700">
                          {eventLabel[s.eventType] || s.eventType}
                        </span>
                        <span className="font-mono text-ink-900 tabular-nums">{s.count}</span>
                      </div>
                      <div className="h-1.5 bg-ink-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-forest-600 rounded-full"
                          style={{ width: `${w}%` }}
                        />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          {/* Live feed */}
          <section className="panel p-7">
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="label-eyebrow mb-1">Live</div>
                <h2 className="display-serif text-2xl text-ink-900">Activity feed</h2>
              </div>
              <Activity className="h-4 w-4 text-ink-400" />
            </div>

            {auditEvents.length === 0 ? (
              <div className="text-sm text-ink-400 py-3">No recent activity.</div>
            ) : (
              <ul className="space-y-3.5 max-h-80 overflow-y-auto pr-1">
                {auditEvents.slice(0, 10).map((e) => (
                  <li key={e.id} className="text-xs flex items-start gap-3">
                    <span
                      className={`h-1.5 w-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                        e.success === false
                          ? 'bg-rust-500'
                          : e.eventType === 'IDOR_ATTEMPT'
                          ? 'bg-rust-500'
                          : 'bg-forest-500'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-ink-900 truncate">
                        {eventLabel[e.eventType] || e.eventType}
                      </div>
                      <div className="text-ink-500 truncate">
                        {e.actorEmail || 'system'}
                      </div>
                    </div>
                    <span className="text-ink-400 tabular-nums whitespace-nowrap flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {timeAgo(e.createdAt)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>
    </Layout>
  );
}

function HealthRow({ icon: Icon, status, label, detail }) {
  const colorMap = {
    ok: 'text-forest-600',
    warn: 'text-gold-600',
    crit: 'text-rust-600',
  };
  return (
    <div className="flex items-start gap-3 p-3 rounded-md bg-paper-100/60 border border-ink-100/70">
      <Icon className={`h-4 w-4 flex-shrink-0 mt-0.5 ${colorMap[status]}`} />
      <div className="min-w-0">
        <div className="text-sm text-ink-900">{label}</div>
        <div className="text-xs text-ink-500 truncate">{detail}</div>
      </div>
    </div>
  );
}

function PopulationBar({ label, count, total, color }) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="mb-4 last:mb-0">
      <div className="flex justify-between text-xs mb-1.5">
        <span className="text-ink-700">{label}</span>
        <span className="font-mono tabular-nums text-ink-900">
          {count}
          <span className="text-ink-400 ml-2">{pct}%</span>
        </span>
      </div>
      <div className="h-2 bg-ink-100 rounded-full overflow-hidden">
        <div
          className={`h-full ${color} rounded-full transition-all duration-700`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
