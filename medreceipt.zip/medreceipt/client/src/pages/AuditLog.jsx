import { useEffect, useState, useMemo } from 'react';
import {
  ScrollText,
  Filter,
  ChevronLeft,
  ChevronRight,
  Search,
  Download,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Eye,
  X,
  Hash,
  Clock,
  MapPin,
  Monitor,
  Layers,
} from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const eventConfig = {
  // Auth
  USER_LOGIN_SUCCESS:        { label: 'Login',             tone: 'forest', category: 'auth' },
  USER_LOGIN_FAILED:         { label: 'Login failed',      tone: 'rust',   category: 'auth' },
  USER_LOGOUT:               { label: 'Logout',            tone: 'ink',    category: 'auth' },
  USER_REGISTERED:           { label: 'Registered',        tone: 'forest', category: 'auth' },
  // MFA
  MFA_ENABLED:               { label: 'MFA enabled',       tone: 'forest', category: 'auth' },
  MFA_DISABLED:              { label: 'MFA disabled',      tone: 'gold',   category: 'auth' },
  MFA_FAILED:                { label: 'MFA failed',        tone: 'rust',   category: 'security' },
  // Password
  PASSWORD_CHANGED:          { label: 'Password changed',  tone: 'gold',   category: 'auth' },
  PASSWORD_RESET_REQUESTED:  { label: 'Reset requested',   tone: 'gold',   category: 'auth' },
  PASSWORD_RESET_COMPLETED:  { label: 'Password reset',    tone: 'forest', category: 'auth' },
  // Security
  ACCOUNT_LOCKED:            { label: 'Account locked',    tone: 'rust',   category: 'security' },
  IDOR_ATTEMPT:              { label: 'IDOR attempt',      tone: 'rust',   category: 'security' },
  // Prescriptions
  PRESCRIPTION_CREATED:      { label: 'Rx created',        tone: 'forest', category: 'rx' },
  PRESCRIPTION_SIGNED:       { label: 'Rx signed',         tone: 'forest', category: 'rx' },
  PRESCRIPTION_VIEWED:       { label: 'Rx viewed',         tone: 'ink',    category: 'rx' },
  PRESCRIPTION_DOWNLOADED:   { label: 'PDF downloaded',    tone: 'ink',    category: 'rx' },
  PRESCRIPTION_STATUS_CHANGED: { label: 'Status changed',  tone: 'gold',   category: 'rx' },
  // Access / admin
  PATIENT_VIEWED:            { label: 'Patient viewed',    tone: 'ink',    category: 'access' },
  USER_PROFILE_UPDATED:      { label: 'Profile updated',   tone: 'ink',    category: 'access' },
  ADMIN_USER_CREATED:        { label: 'User provisioned',  tone: 'forest', category: 'admin' },
  ADMIN_USER_UPDATED:        { label: 'User updated',      tone: 'gold',   category: 'admin' },
  ADMIN_USER_DEACTIVATED:    { label: 'User deactivated',  tone: 'rust',   category: 'admin' },
};

const toneClasses = {
  forest: 'bg-forest-100 text-forest-800 border-forest-200',
  ink: 'bg-ink-100 text-ink-700 border-ink-200',
  rust: 'bg-rust-50 text-rust-700 border-rust-200',
  gold: 'bg-gold-50 text-gold-800 border-gold-200',
};

const toneDots = {
  forest: 'bg-forest-600',
  ink: 'bg-ink-500',
  rust: 'bg-rust-500',
  gold: 'bg-gold-500',
};

function fmtDate(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export default function AuditLogPage() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [stats, setStats] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [eventType, setEventType] = useState('');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    setPage(1);
  }, [eventType]);

  useEffect(() => {
    let ignore = false;
    setLoading(true);
    api
      .get('/audit', {
        params: { page, limit: 25, eventType: eventType || undefined },
      })
      .then((r) => {
        if (ignore) return;
        setItems(r.data.data || []);
        setStats(r.data.stats || []);
        setPages(r.data.pagination?.pages || 1);
        setTotal(r.data.pagination?.total || 0);
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, [page, eventType]);

  const filtered = useMemo(() => {
    if (!search.trim()) return items;
    const q = search.trim().toLowerCase();
    return items.filter(
      (e) =>
        (e.actorEmail || '').toLowerCase().includes(q) ||
        (e.eventType || '').toLowerCase().includes(q) ||
        (e.resourceId || '').toLowerCase().includes(q) ||
        (e.ipAddress || '').toLowerCase().includes(q)
    );
  }, [items, search]);

  const summary = useMemo(() => {
    const successCount = items.filter((e) => e.success !== false).length;
    const failCount = items.filter((e) => e.success === false).length;
    const securityCount = items.filter((e) =>
      ['IDOR_ATTEMPT', 'USER_LOGIN_FAILED', 'ACCOUNT_LOCKED', 'MFA_FAILED'].includes(e.eventType)
    ).length;
    return { successCount, failCount, securityCount };
  }, [items]);

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(filtered, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medreceipt-audit-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Layout
      eyebrow={user?.role === 'DOCTOR' ? 'My activity' : 'Compliance'}
      title="Audit trail"
      action={
        <button onClick={exportJSON} className="btn-secondary">
          <Download className="h-4 w-4" />
          Export visible
        </button>
      }
    >
      {/* Stats strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCell
          label="Total events"
          value={total}
          icon={Layers}
          tone="ink"
        />
        <StatCell
          label="Successful"
          value={summary.successCount}
          icon={CheckCircle2}
          tone="forest"
        />
        <StatCell
          label="Failed"
          value={summary.failCount}
          icon={XCircle}
          tone={summary.failCount > 0 ? 'rust' : 'ink'}
        />
        <StatCell
          label="Security flags"
          value={summary.securityCount}
          icon={AlertTriangle}
          tone={summary.securityCount > 0 ? 'rust' : 'forest'}
        />
      </div>

      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        {/* LEFT — log table */}
        <section className="panel p-0 overflow-hidden min-h-[500px]">
          {/* Filters */}
          <div className="px-6 py-4 border-b border-ink-100 flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter by email, event, resource, or IP"
                className="input pl-9 text-sm"
              />
            </div>
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value)}
              className="input text-sm w-auto min-w-[200px]"
            >
              <option value="">All event types</option>
              {Object.entries(eventConfig).map(([k, v]) => (
                <option key={k} value={k}>
                  {v.label}
                </option>
              ))}
            </select>
            {(eventType || search) && (
              <button
                onClick={() => {
                  setEventType('');
                  setSearch('');
                }}
                className="btn-ghost text-xs"
              >
                <X className="h-3.5 w-3.5" />
                Clear
              </button>
            )}
          </div>

          {/* Log entries */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10px] uppercase tracking-[0.18em] text-ink-400 border-b border-ink-100">
                  <th className="text-left font-medium px-6 py-3">Event</th>
                  <th className="text-left font-medium px-3 py-3">Actor</th>
                  <th className="text-left font-medium px-3 py-3">Resource</th>
                  <th className="text-left font-medium px-3 py-3">When</th>
                  <th className="text-right font-medium px-6 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {loading && (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-ink-400">
                      Loading audit trail…
                    </td>
                  </tr>
                )}
                {!loading && filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-ink-400">
                      <ScrollText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      No events match the current filter.
                    </td>
                  </tr>
                )}
                {!loading &&
                  filtered.map((e) => {
                    const cfg =
                      eventConfig[e.eventType] || {
                        label: e.eventType,
                        tone: 'ink',
                      };
                    return (
                      <tr
                        key={e._id || e.id}
                        onClick={() => setSelected(e)}
                        className={`cursor-pointer hover:bg-paper-100/70 transition ${
                          selected && (selected._id || selected.id) === (e._id || e.id)
                            ? 'bg-paper-100'
                            : ''
                        }`}
                      >
                        <td className="px-6 py-3.5">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium border ${toneClasses[cfg.tone]}`}
                          >
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${toneDots[cfg.tone]}`}
                            />
                            {cfg.label}
                          </span>
                        </td>
                        <td className="px-3 py-3.5 text-xs text-ink-700 truncate max-w-[200px]">
                          {e.actorEmail || (
                            <span className="text-ink-400">system</span>
                          )}
                        </td>
                        <td className="px-3 py-3.5 text-xs">
                          {e.resourceType ? (
                            <div className="flex flex-col">
                              <span className="text-ink-700">{e.resourceType}</span>
                              {e.resourceId && (
                                <span className="font-mono text-[10px] text-ink-400 truncate max-w-[180px]">
                                  {e.resourceId.slice(-12)}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-ink-400">—</span>
                          )}
                        </td>
                        <td className="px-3 py-3.5 text-xs text-ink-500 tabular-nums">
                          <div>{timeAgo(e.createdAt)}</div>
                          <div className="text-[10px] text-ink-400">
                            {new Date(e.createdAt).toLocaleTimeString()}
                          </div>
                        </td>
                        <td className="px-6 py-3.5 text-right">
                          {e.success === false ? (
                            <span className="inline-flex items-center gap-1 text-xs text-rust-700">
                              <XCircle className="h-3.5 w-3.5" />
                              Failed
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs text-forest-700">
                              <CheckCircle2 className="h-3.5 w-3.5" />
                              OK
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {pages > 1 && (
            <div className="px-6 py-4 border-t border-ink-100 flex items-center justify-between text-xs">
              <span className="text-ink-500">
                Page <span className="font-mono text-ink-900">{page}</span> of{' '}
                <span className="font-mono text-ink-900">{pages}</span>
                <span className="text-ink-400 ml-2">({total} entries)</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                  className="btn-ghost disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                  Previous
                </button>
                <button
                  disabled={page >= pages}
                  onClick={() => setPage((p) => p + 1)}
                  className="btn-ghost disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Next
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </section>

        {/* RIGHT — sidebar */}
        <aside className="space-y-6">
          {/* Event detail or distribution */}
          {selected ? (
            <EventDetail event={selected} onClose={() => setSelected(null)} />
          ) : (
            <section className="panel p-6">
              <div className="label-eyebrow mb-4">Distribution</div>
              {stats.length === 0 ? (
                <div className="text-sm text-ink-400 py-3">No data.</div>
              ) : (
                <ul className="space-y-2.5">
                  {stats.slice(0, 8).map((s) => {
                    const cfg =
                      eventConfig[s._id] || {
                        label: s._id,
                        tone: 'ink',
                      };
                    const max = stats[0].count || 1;
                    const w = Math.max(8, (s.count / max) * 100);
                    return (
                      <li key={s._id} className="text-xs">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-ink-700 flex items-center gap-1.5">
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${toneDots[cfg.tone]}`}
                            />
                            {cfg.label}
                          </span>
                          <span className="font-mono text-ink-900 tabular-nums">
                            {s.count}
                          </span>
                        </div>
                        <div className="h-1 bg-ink-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${toneDots[cfg.tone]}`}
                            style={{ width: `${w}%` }}
                          />
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          )}

          {/* Integrity notice */}
          <section className="panel p-6 bg-forest-900 text-paper-100">
            <div className="label-eyebrow text-paper-200 mb-3">Integrity</div>
            <h3 className="display-serif text-xl text-paper-50 mb-2">
              Append-only log
            </h3>
            <p className="text-xs text-paper-200/80 leading-relaxed mb-4">
              Audit entries are immutable. Update and delete operations are
              denied at the database layer via pre-save hooks. Every privileged
              action — including viewing this trail — is itself recorded.
            </p>
            <div className="text-[10px] uppercase tracking-[0.18em] text-paper-200/60">
              IEEE 1016-2009 §7.3
            </div>
          </section>
        </aside>
      </div>
    </Layout>
  );
}

function StatCell({ label, value, icon: Icon, tone }) {
  const toneCol = {
    forest: 'text-forest-700',
    rust: 'text-rust-700',
    gold: 'text-gold-700',
    ink: 'text-ink-700',
  };
  return (
    <div className="panel-flat p-5 flex items-center gap-4">
      <div className="h-9 w-9 rounded-md bg-paper-100 flex items-center justify-center">
        <Icon className={`h-4 w-4 ${toneCol[tone]}`} />
      </div>
      <div>
        <div className="label-eyebrow text-ink-500 mb-0.5">{label}</div>
        <div className="display-serif text-3xl text-ink-900 leading-none">
          {value}
        </div>
      </div>
    </div>
  );
}

function EventDetail({ event, onClose }) {
  const cfg = eventConfig[event.eventType] || { label: event.eventType, tone: 'ink' };
  return (
    <section className="panel p-6 fade-up">
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="label-eyebrow text-ink-500 mb-1.5">Event detail</div>
          <span
            className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium border ${toneClasses[cfg.tone]}`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${toneDots[cfg.tone]}`} />
            {cfg.label}
          </span>
        </div>
        <button onClick={onClose} className="text-ink-400 hover:text-ink-700">
          <X className="h-4 w-4" />
        </button>
      </div>

      <dl className="space-y-3 text-xs border-t border-ink-100 pt-4">
        <Row icon={Hash} label="Event ID">
          <span className="font-mono">{(event._id || event.id || '').slice(-16)}</span>
        </Row>
        <Row icon={Clock} label="Timestamp">
          <span>{fmtDate(event.createdAt)}</span>
        </Row>
        <Row icon={Eye} label="Actor">
          <span>{event.actorEmail || 'system'}</span>
        </Row>
        {event.resourceType && (
          <Row icon={Layers} label="Resource">
            <div className="flex flex-col items-end">
              <span>{event.resourceType}</span>
              {event.resourceId && (
                <span className="font-mono text-[10px] text-ink-400 truncate max-w-[180px]">
                  {event.resourceId}
                </span>
              )}
            </div>
          </Row>
        )}
        {event.ipAddress && (
          <Row icon={MapPin} label="IP address">
            <span className="font-mono">{event.ipAddress}</span>
          </Row>
        )}
        {event.userAgent && (
          <Row icon={Monitor} label="Client">
            <span className="truncate max-w-[180px] text-right">
              {event.userAgent.split(' ')[0]}
            </span>
          </Row>
        )}
        <Row
          icon={event.success === false ? XCircle : CheckCircle2}
          label="Outcome"
        >
          <span
            className={
              event.success === false ? 'text-rust-700' : 'text-forest-700'
            }
          >
            {event.success === false ? 'Failed' : 'Success'}
          </span>
        </Row>
      </dl>

      {event.metadata && Object.keys(event.metadata).length > 0 && (
        <div className="mt-4 pt-4 border-t border-ink-100">
          <div className="label-eyebrow mb-2">Metadata</div>
          <pre className="text-[10px] font-mono text-ink-700 bg-paper-100 rounded-md p-3 overflow-x-auto leading-relaxed max-h-48">
            {JSON.stringify(event.metadata, null, 2)}
          </pre>
        </div>
      )}
    </section>
  );
}

function Row({ icon: Icon, label, children }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="flex items-center gap-1.5 text-ink-500">
        <Icon className="h-3 w-3" />
        {label}
      </dt>
      <dd className="text-ink-900 text-right truncate">{children}</dd>
    </div>
  );
}
