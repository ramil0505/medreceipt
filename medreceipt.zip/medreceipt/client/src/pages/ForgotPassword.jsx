import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowRight, ArrowLeft, AlertTriangle, BadgeCheck, Copy, Check } from 'lucide-react';
import api from '../api/client.js';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  // Dev-mode: server returns the token directly when NODE_ENV !== production
  const [devToken, setDevToken] = useState('');
  const [copied, setCopied] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const r = await api.post('/auth/forgot-password', { email });
      setDevToken(r.data.data?.resetToken || '');
      setSubmitted(true);
    } catch (err) {
      setError(err.response?.data?.error?.message || 'Something went wrong. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const copy = () => {
    navigator.clipboard.writeText(devToken);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-paper-50">
      <div className="w-full max-w-md">
        <div className="panel p-10 fade-up">

          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
              <Mail size={20} strokeWidth={1.5} />
            </div>
            <div className="label-eyebrow">Password recovery</div>
          </div>

          {!submitted ? (
            <>
              <h1 className="display-serif text-4xl text-ink-900 mb-2 leading-none">
                Forgot your password?
              </h1>
              <p className="text-sm text-ink-600 mb-8">
                Enter your email and we'll send a reset link. The link expires in 15 minutes.
              </p>

              <form onSubmit={submit} className="space-y-4">
                <div>
                  <label className="field-label">Email address</label>
                  <input
                    type="email"
                    className="input"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    required
                    autoFocus
                    autoComplete="email"
                  />
                </div>

                {error && (
                  <div className="text-rust-600 text-sm bg-rust-50 border border-rust-200 rounded-xl px-4 py-3 flex items-center gap-2">
                    <AlertTriangle size={15} className="flex-shrink-0" />
                    {error}
                  </div>
                )}

                <button type="submit" disabled={loading} className="btn-primary w-full">
                  {loading ? 'Sending…' : 'Send reset link'}
                  <ArrowRight size={16} />
                </button>
              </form>
            </>
          ) : (
            <>
              <div className="flex items-center justify-center w-14 h-14 rounded-full bg-forest-50 mb-6">
                <BadgeCheck className="h-7 w-7 text-forest-700" />
              </div>
              <h1 className="display-serif text-3xl text-ink-900 mb-2 leading-tight">
                Check your email.
              </h1>
              <p className="text-sm text-ink-600 mb-6">
                If <span className="font-medium text-ink-800">{email}</span> has an account,
                a reset link was sent. It expires in 15 minutes.
              </p>

              {/* Dev mode token — only shown when server returns it */}
              {devToken && (
                <div className="mb-6 p-4 rounded-xl bg-amber-50 border border-amber-200">
                  <div className="text-xs font-medium text-amber-800 mb-2 flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 rounded-full bg-amber-500" />
                    Dev mode — reset token (not shown in production)
                  </div>
                  <div className="flex items-start gap-2">
                    <code className="text-[10px] font-mono text-amber-900 break-all flex-1 leading-relaxed">
                      {devToken}
                    </code>
                    <button onClick={copy} className="flex-shrink-0 text-amber-700 hover:text-amber-900 mt-0.5">
                      {copied ? <Check size={14} /> : <Copy size={14} />}
                    </button>
                  </div>
                  <Link
                    to={`/reset-password?token=${encodeURIComponent(devToken)}`}
                    className="mt-3 inline-flex items-center gap-1.5 text-xs text-amber-800 font-medium hover:underline"
                  >
                    Use this token to reset → <ArrowRight size={12} />
                  </Link>
                </div>
              )}

              <button
                onClick={() => { setSubmitted(false); setDevToken(''); }}
                className="btn-secondary w-full mb-3 text-sm"
              >
                Try a different email
              </button>
            </>
          )}

          <Link
            to="/login"
            className="flex items-center gap-1.5 text-sm text-ink-500 hover:text-ink-800 transition-colors mt-4"
          >
            <ArrowLeft size={14} /> Back to login
          </Link>
        </div>
      </div>
    </div>
  );
}
