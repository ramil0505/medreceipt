import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, ArrowRight, Pill, FileText } from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function PatientDashboard() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);

  useEffect(() => {
    api.get('/prescriptions?limit=100').then((r) => setItems(r.data.data));
  }, []);

  const active = items.filter((r) => r.status === 'ACTIVE');
  const past = items.filter((r) => r.status !== 'ACTIVE' && r.status !== 'DRAFT');

  return (
    <Layout
      eyebrow={`Patient · ${user?.fullName}`}
      title={
        <>
          Your file,
          <br />
          <em className="font-extralight italic">in good order.</em>
        </>
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <Stat label="Active" value={active.length} accent="forest" />
        <Stat label="Total" value={items.length} />
        <Stat label="Dispensed" value={items.filter((r) => r.status === 'DISPENSED').length} />
        <Stat label="Expired" value={items.filter((r) => r.status === 'EXPIRED').length} />
      </div>

      {/* Active band — card view */}
      <div className="mb-10">
        <div className="flex items-end justify-between mb-4">
          <div>
            <div className="label-eyebrow mb-1">Currently active</div>
            <div className="display-serif text-3xl">For your attention</div>
          </div>
        </div>

        {active.length === 0 ? (
          <div className="panel p-10 text-center">
            <Pill size={28} className="mx-auto text-ink-400 mb-3" />
            <div className="text-sm text-ink-600">No active prescriptions at this time.</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {active.map((rx, i) => (
              <Link
                key={rx._id}
                to={`/prescriptions/${rx._id}`}
                className="panel p-6 hover:shadow-lg transition fade-up group"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-11 h-11 rounded-2xl bg-forest-50 text-forest-700 flex items-center justify-center">
                    <Pill size={18} strokeWidth={1.5} />
                  </div>
                  <StatusBadge status={rx.status} />
                </div>
                <div className="display-serif text-2xl text-ink-900 leading-tight mb-1">
                  {rx.medication}
                </div>
                <div className="text-sm text-ink-600 mb-4">{rx.diagnosis}</div>
                <div className="space-y-2 text-xs">
                  <RxRow label="Dosage" value={rx.dosage} />
                  <RxRow label="Prescribed by" value={rx.doctorId?.fullName} />
                  <RxRow
                    label="Issued"
                    value={new Date(rx.signedAt || rx.createdAt).toLocaleDateString()}
                  />
                </div>
                <div className="divider-soft my-4" />
                <div className="flex items-center justify-between text-xs">
                  <span className="text-ink-500">Tap for instructions & PDF</span>
                  <span className="text-forest-700 group-hover:translate-x-0.5 transition flex items-center gap-1">
                    Open <ArrowRight size={12} />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* History */}
      <div>
        <div className="flex items-end justify-between mb-4">
          <div>
            <div className="label-eyebrow mb-1">Archive</div>
            <div className="display-serif text-3xl">History</div>
          </div>
          <div className="text-xs text-ink-500">{past.length} entries</div>
        </div>
        <div className="panel divide-y divide-ink-900/[0.05]">
          {past.length === 0 ? (
            <div className="px-6 py-10 text-center text-sm text-ink-500">
              <FileText size={24} className="mx-auto mb-2 text-ink-400" /> No past prescriptions.
            </div>
          ) : (
            past.map((rx) => (
              <Link
                key={rx._id}
                to={`/prescriptions/${rx._id}`}
                className="flex items-center gap-4 px-6 py-4 hover:bg-paper-100/60 transition"
              >
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-ink-900 truncate">{rx.medication}</div>
                  <div className="text-xs text-ink-500 truncate">{rx.diagnosis}</div>
                </div>
                <StatusBadge status={rx.status} />
                <span className="text-xs text-ink-500 hidden md:block w-24 text-right">
                  {new Date(rx.createdAt).toLocaleDateString()}
                </span>
              </Link>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div className="panel p-5">
      <div className="label-eyebrow">{label}</div>
      <div
        className={`display-serif text-5xl mt-2 leading-none ${
          accent === 'forest' ? 'text-forest-700' : 'text-ink-900'
        }`}
      >
        {value}
      </div>
    </div>
  );
}

function RxRow({ label, value }) {
  return (
    <div className="grid grid-cols-[100px_1fr] gap-2">
      <span className="text-ink-500">{label}</span>
      <span className="text-ink-800 truncate">{value || '—'}</span>
    </div>
  );
}
