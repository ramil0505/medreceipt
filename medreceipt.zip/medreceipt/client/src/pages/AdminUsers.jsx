import { useEffect, useState, useMemo } from 'react';
import {
  Search,
  UserPlus,
  Stethoscope,
  Users as UsersIcon,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Unlock,
  ChevronLeft,
  ChevronRight,
  Filter,
  X,
  Eye,
  EyeOff,
  AlertTriangle,
  UserCheck,
} from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';

const roleConfig = {
  DOCTOR: {
    label: 'Physician',
    icon: Stethoscope,
    chipClass: 'bg-forest-100 text-forest-800',
    dot: 'bg-forest-600',
  },
  PATIENT: {
    label: 'Patient',
    icon: UsersIcon,
    chipClass: 'bg-ink-100 text-ink-700',
    dot: 'bg-ink-500',
  },
  ADMIN: {
    label: 'Operator',
    icon: ShieldCheck,
    chipClass: 'bg-gold-100 text-gold-800',
    dot: 'bg-gold-600',
  },
};

function fmtDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function maskId(id) {
  if (!id) return '—';
  if (id.length <= 4) return id;
  return id.slice(0, 3) + '•••' + id.slice(-2);
}

function CreateUserModal({ onClose, onCreated }) {
  const [form, setForm] = useState({
    fullName: '', email: '', password: '', personalId: '',
    phone: '', role: 'DOCTOR', licenseNumber: '', specialty: '', department: '',
  });
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const submit = async () => {
    setError('');
    if (!form.fullName || !form.email || !form.password || !form.personalId || !form.phone) {
      setError('All required fields must be filled.'); return;
    }
    setSaving(true);
    try {
      const r = await api.post('/users', form);
      onCreated(r.data.data);
    } catch (e) {
      setError(e.response?.data?.error?.message || 'Could not create account.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/40 backdrop-blur-sm p-4">
      <div className="bg-paper-50 rounded-2xl shadow-xl w-full max-w-lg p-8 relative max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 text-ink-400 hover:text-ink-700">
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
            <UserCheck size={20} />
          </div>
          <div>
            <div className="label-eyebrow">Provision account</div>
            <div className="text-sm text-ink-600">Create a new system user</div>
          </div>
        </div>

        {error && (
          <div className="mb-4 px-4 py-3 rounded-xl bg-rust-50 border border-rust-200 text-rust-700 text-sm flex items-center gap-2">
            <AlertTriangle size={15} />{error}
          </div>
        )}

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="field-label">Full name *</label>
              <input className="input" value={form.fullName} onChange={e => set('fullName', e.target.value)} placeholder="Dr. Jane Smith" />
            </div>
            <div>
              <label className="field-label">Email *</label>
              <input type="email" className="input" value={form.email} onChange={e => set('email', e.target.value)} placeholder="jane@clinic.io" />
            </div>
            <div>
              <label className="field-label">Phone *</label>
              <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+371-200-00001" />
            </div>
            <div>
              <label className="field-label">Personal ID *</label>
              <input className="input" value={form.personalId} onChange={e => set('personalId', e.target.value)} placeholder="DOC-004" />
            </div>
            <div>
              <label className="field-label">Role *</label>
              <select className="input" value={form.role} onChange={e => set('role', e.target.value)}>
                <option value="DOCTOR">Doctor</option>
                <option value="PATIENT">Patient</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>
            <div className="col-span-2 relative">
              <label className="field-label">Password * <span className="text-ink-400 font-normal text-[10px]">(12+ chars, upper/lower/digit/symbol)</span></label>
              <input type={showPw ? 'text' : 'password'} className="input pr-10" value={form.password} onChange={e => set('password', e.target.value)} placeholder="••••••••••••" />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-[34px] text-ink-400 hover:text-ink-700">
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
            {form.role === 'DOCTOR' && (
              <>
                <div>
                  <label className="field-label">Specialty</label>
                  <input className="input" value={form.specialty} onChange={e => set('specialty', e.target.value)} placeholder="Cardiology" />
                </div>
                <div>
                  <label className="field-label">Department</label>
                  <input className="input" value={form.department} onChange={e => set('department', e.target.value)} placeholder="Cardiology Ward" />
                </div>
                <div className="col-span-2">
                  <label className="field-label">License number</label>
                  <input className="input" value={form.licenseNumber} onChange={e => set('licenseNumber', e.target.value)} placeholder="MD-2026-0XXX" />
                </div>
              </>
            )}
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={submit} disabled={saving} className="btn-primary flex-1">
            {saving ? 'Creating…' : 'Create account'}
          </button>
          <button onClick={onClose} className="btn-secondary">Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [showCreate, setShowCreate] = useState(false);

  // debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 280);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    setPage(1);
  }, [debounced, roleFilter]);

  useEffect(() => {
    let ignore = false;
    setLoading(true);
    api
      .get('/users', {
        params: { page, limit: 12, search: debounced || undefined },
      })
      .then((r) => {
        if (ignore) return;
        setUsers(r.data.data || []);
        setPages(r.data.pagination?.pages || 1);
        setTotal(r.data.pagination?.total || 0);
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, [page, debounced]);

  const visible = useMemo(() => {
    if (roleFilter === 'ALL') return users;
    return users.filter((u) => u.role === roleFilter);
  }, [users, roleFilter]);

  const counts = useMemo(() => {
    return {
      ALL: users.length,
      DOCTOR: users.filter((u) => u.role === 'DOCTOR').length,
      PATIENT: users.filter((u) => u.role === 'PATIENT').length,
      ADMIN: users.filter((u) => u.role === 'ADMIN').length,
    };
  }, [users]);

  return (
    <Layout
      eyebrow="Operator console"
      title="User directory"
      action={
        <div className="flex items-center gap-3">
          <div className="text-xs text-ink-500">{total} record{total === 1 ? '' : 's'} total</div>
          <button onClick={() => setShowCreate(true)} className="btn-primary text-xs py-2">
            <UserPlus className="h-3.5 w-3.5" />Provision account
          </button>
        </div>
      }
    >
      {showCreate && (
        <CreateUserModal
          onClose={() => setShowCreate(false)}
          onCreated={(newUser) => {
            setUsers((prev) => [newUser, ...prev]);
            setTotal((t) => t + 1);
            setShowCreate(false);
            setSelected(newUser);
          }}
        />
      )}

      <div className="grid lg:grid-cols-[1fr_360px] gap-6 max-w-[1400px]">
        {/* LEFT — table */}
        <section className="panel p-0 overflow-hidden">
          {/* Toolbar */}
          <div className="px-6 py-5 border-b border-ink-100 flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, email, or personal ID"
                className="input pl-9"
              />
            </div>
            <div className="flex items-center gap-1 p-1 bg-paper-100 rounded-md border border-ink-100">
              {['ALL', 'DOCTOR', 'PATIENT', 'ADMIN'].map((r) => (
                <button
                  key={r}
                  onClick={() => setRoleFilter(r)}
                  className={`px-3 py-1.5 text-xs font-medium rounded transition ${
                    roleFilter === r
                      ? 'bg-white text-ink-900 shadow-sm'
                      : 'text-ink-500 hover:text-ink-800'
                  }`}
                >
                  {r === 'ALL' ? 'All' : roleConfig[r].label}
                  <span className="ml-1.5 text-ink-400 tabular-nums">
                    {counts[r]}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10px] uppercase tracking-[0.18em] text-ink-400 border-b border-ink-100">
                  <th className="text-left font-medium px-6 py-3">Account</th>
                  <th className="text-left font-medium px-3 py-3">Role</th>
                  <th className="text-left font-medium px-3 py-3">Personal ID</th>
                  <th className="text-left font-medium px-3 py-3">Status</th>
                  <th className="text-left font-medium px-3 py-3">Joined</th>
                  <th className="px-6 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {loading && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-ink-400">
                      Loading directory…
                    </td>
                  </tr>
                )}
                {!loading && visible.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-ink-400">
                      No users match the current filter.
                    </td>
                  </tr>
                )}
                {!loading &&
                  visible.map((u) => {
                    const cfg = roleConfig[u.role] || roleConfig.PATIENT;
                    const Icon = cfg.icon;
                    const isLocked =
                      u.lockoutUntil && new Date(u.lockoutUntil).getTime() > Date.now();
                    return (
                      <tr
                        key={u.id}
                        onClick={() => setSelected(u)}
                        className={`cursor-pointer hover:bg-paper-100/70 transition ${
                          selected?.id === u.id ? 'bg-paper-100' : ''
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div
                              className={`h-9 w-9 rounded-full ${cfg.dot} bg-opacity-15 flex items-center justify-center text-xs font-medium`}
                              style={{
                                backgroundColor: 'rgba(0,0,0,0.04)',
                              }}
                            >
                              <Icon className="h-4 w-4 text-ink-700" />
                            </div>
                            <div className="min-w-0">
                              <div className="text-ink-900 font-medium truncate max-w-[220px]">
                                {u.fullName}
                              </div>
                              <div className="text-xs text-ink-500 truncate max-w-[220px]">
                                {u.email}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-4">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${cfg.chipClass}`}
                          >
                            <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
                            {cfg.label}
                          </span>
                        </td>
                        <td className="px-3 py-4 font-mono text-xs text-ink-700">
                          {maskId(u.personalId)}
                        </td>
                        <td className="px-3 py-4">
                          <div className="flex flex-col gap-0.5 text-xs">
                            <span
                              className={`flex items-center gap-1 ${
                                u.isVerified ? 'text-forest-700' : 'text-gold-700'
                              }`}
                            >
                              <CheckCircle2 className="h-3 w-3" />
                              {u.isVerified ? 'Verified' : 'Pending'}
                            </span>
                            {isLocked ? (
                              <span className="flex items-center gap-1 text-rust-700">
                                <Lock className="h-3 w-3" />
                                Locked
                              </span>
                            ) : u.mfaEnabled ? (
                              <span className="flex items-center gap-1 text-ink-600">
                                <ShieldCheck className="h-3 w-3" />
                                MFA on
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 text-ink-400">
                                <Unlock className="h-3 w-3" />
                                MFA off
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-4 text-xs text-ink-500 tabular-nums">
                          {fmtDate(u.createdAt)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className="text-xs text-ink-400">View →</span>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {pages > 1 && (
            <div className="px-6 py-4 border-t border-ink-100 flex items-center justify-between text-xs">
              <span className="text-ink-500">
                Page <span className="font-mono text-ink-900">{page}</span> of{' '}
                <span className="font-mono text-ink-900">{pages}</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                  className="btn-ghost disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                  Previous
                </button>
                <button
                  disabled={page >= pages}
                  onClick={() => setPage((p) => p + 1)}
                  className="btn-ghost disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Next
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </section>

        {/* RIGHT — detail panel */}
        <aside className="lg:sticky lg:top-6 self-start">
          {selected ? (
            <UserDetail user={selected} onClose={() => setSelected(null)} />
          ) : (
            <div className="panel p-7 text-center">
              <div className="h-12 w-12 rounded-full bg-paper-100 mx-auto mb-3 flex items-center justify-center">
                <UsersIcon className="h-5 w-5 text-ink-400" />
              </div>
              <div className="display-serif text-xl text-ink-900 mb-1">
                Select a record
              </div>
              <p className="text-sm text-ink-500">
                Click any row to inspect account details, security state, and
                activity context.
              </p>
            </div>
          )}
        </aside>
      </div>
    </Layout>
  );
}

function UserDetail({ user, onClose }) {
  const cfg = roleConfig[user.role] || roleConfig.PATIENT;
  const Icon = cfg.icon;
  const isLocked =
    user.lockoutUntil && new Date(user.lockoutUntil).getTime() > Date.now();

  return (
    <div className="panel p-7 fade-up">
      <div className="flex items-start justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-full bg-paper-100 flex items-center justify-center">
            <Icon className="h-5 w-5 text-ink-700" />
          </div>
          <div className="min-w-0">
            <div className="display-serif text-xl text-ink-900 leading-tight truncate">
              {user.fullName}
            </div>
            <span
              className={`inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded text-[10px] font-medium ${cfg.chipClass}`}
            >
              {cfg.label}
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-ink-400 hover:text-ink-700 text-sm"
        >
          ✕
        </button>
      </div>

      <dl className="space-y-3 text-sm border-t border-ink-100 pt-5">
        <Field label="Email" value={user.email} mono />
        <Field label="Phone" value={user.phone || '—'} />
        <Field label="Personal ID" value={maskId(user.personalId)} mono />
        {user.role === 'DOCTOR' && (
          <>
            <Field label="License" value={user.licenseNumber || '—'} mono />
            <Field label="Specialty" value={user.specialty || '—'} />
          </>
        )}
        <Field label="Joined" value={fmtDate(user.createdAt)} />
      </dl>

      <div className="mt-6 pt-5 border-t border-ink-100">
        <div className="label-eyebrow mb-3">Security</div>
        <ul className="space-y-2 text-xs">
          <SecRow ok={user.isVerified} label="Email verified" />
          <SecRow ok={user.mfaEnabled} label="MFA enabled" />
          <SecRow
            ok={!isLocked}
            label={isLocked ? 'Account locked' : 'Account unlocked'}
            warn={isLocked}
          />
          <SecRow
            ok={(user.failedLoginAttempts || 0) < 3}
            label={`${user.failedLoginAttempts || 0} recent failed attempts`}
          />
        </ul>
      </div>

      {user.role === 'DOCTOR' && (
        <div className="mt-4 border-t border-ink-100 pt-4">
          <div className="label-eyebrow mb-2">Clinical details</div>
          <dl className="space-y-2 text-xs">
            <Field label="Specialty" value={user.specialty || '—'} />
            <Field label="Department" value={user.department || '—'} />
            <Field label="License" value={user.licenseNumber || '—'} mono />
          </dl>
        </div>
      )}
      {user.lastLoginAt && (
        <div className="mt-2 text-[11px] text-ink-400">
          Last login: {new Date(user.lastLoginAt).toLocaleString()}
        </div>
      )}
    </div>
  );
}

function Field({ label, value, mono = false }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="text-ink-500 text-xs">{label}</dt>
      <dd
        className={`text-ink-900 text-right truncate max-w-[200px] ${
          mono ? 'font-mono text-xs' : ''
        }`}
      >
        {value}
      </dd>
    </div>
  );
}

function SecRow({ ok, label, warn = false }) {
  return (
    <li className="flex items-center gap-2.5">
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          warn ? 'bg-rust-500' : ok ? 'bg-forest-600' : 'bg-ink-300'
        }`}
      />
      <span className={warn ? 'text-rust-700' : 'text-ink-700'}>{label}</span>
    </li>
  );
}
