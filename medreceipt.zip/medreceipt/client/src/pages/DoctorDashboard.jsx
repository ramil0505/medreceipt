import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, FileText, ClipboardCheck, Activity, ArrowRight } from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function DoctorDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState({
    patients: 0,
    activeRx: 0,
    draftRx: 0,
    recent: [],
    audit: [],
  });

  useEffect(() => {
    Promise.all([
      api.get('/users?limit=1'),
      api.get('/prescriptions?limit=5'),
      api.get('/audit?limit=6'),
    ]).then(([u, rx, a]) => {
      const items = rx.data.data;
      setData({
        patients: u.data.pagination.total,
        activeRx: items.filter((r) => r.status === 'ACTIVE').length,
        draftRx: items.filter((r) => r.status === 'DRAFT').length,
        recent: items,
        audit: a.data.data,
      });
    });
  }, []);

  const greeting =
    new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 18 ? 'Good afternoon' : 'Good evening';
  const firstName = user?.fullName?.split(' ').slice(-1)[0] || 'Doctor';

  return (
    <Layout
      eyebrow={`${greeting}, ${user?.fullName}`}
      title={
        <>
          The clinic, <em className="font-extralight italic">at a glance.</em>
        </>
      }
      action={
        <Link to="/doctor/patients" className="btn-primary">
          Find a patient <ArrowRight size={16} />
        </Link>
      }
    >
      {/* KPI grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
        {[
          {
            k: 'Patients on file',
            v: data.patients,
            icon: Users,
            sub: 'Across all clinicians',
            tone: 'forest',
          },
          {
            k: 'Active prescriptions',
            v: data.activeRx,
            icon: ClipboardCheck,
            sub: 'Signed and dispensable',
            tone: 'forest',
          },
          {
            k: 'Drafts awaiting signature',
            v: data.draftRx,
            icon: FileText,
            sub: 'Pending your approval',
            tone: 'gold',
          },
        ].map((c, i) => (
          <div
            key={c.k}
            className="panel p-6 fade-up"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className="flex items-start justify-between">
              <div className="label-eyebrow">{c.k}</div>
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  c.tone === 'gold' ? 'bg-gold-400/15 text-gold-500' : 'bg-forest-50 text-forest-700'
                }`}
              >
                <c.icon size={16} strokeWidth={1.6} />
              </div>
            </div>
            <div className="display-serif text-6xl mt-3 leading-none text-ink-900">
              {c.v}
            </div>
            <div className="text-xs text-ink-500 mt-2">{c.sub}</div>
          </div>
        ))}
      </div>

      {/* Recent prescriptions + audit feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 panel">
          <div className="flex items-center justify-between px-6 pt-5 pb-3">
            <div>
              <div className="label-eyebrow mb-1">Recent prescriptions</div>
              <div className="display-serif text-2xl">Latest activity</div>
            </div>
            <Link
              to="/doctor/prescriptions"
              className="text-xs text-forest-700 hover:underline flex items-center gap-1"
            >
              View all <ArrowRight size={12} />
            </Link>
          </div>
          <div className="divider-soft" />
          <div className="divide-y divide-ink-900/[0.05]">
            {data.recent.length === 0 && (
              <div className="px-6 py-10 text-center text-sm text-ink-500">No prescriptions yet.</div>
            )}
            {data.recent.map((rx) => (
              <Link
                key={rx._id}
                to={`/prescriptions/${rx._id}`}
                className="flex items-center gap-4 px-6 py-4 hover:bg-paper-100/60 transition"
              >
                <div className="w-10 h-10 rounded-full bg-paper-200 flex items-center justify-center text-xs font-medium text-ink-700">
                  {rx.patientId?.fullName?.split(' ').map((s) => s[0]).slice(0, 2).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-ink-900 truncate">{rx.medication}</div>
                  <div className="text-xs text-ink-500 truncate">
                    {rx.patientId?.fullName} · {rx.diagnosis}
                  </div>
                </div>
                <StatusBadge status={rx.status} />
                <div className="text-xs text-ink-500 hidden sm:block w-20 text-right">
                  {new Date(rx.createdAt).toLocaleDateString()}
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="flex items-center justify-between px-6 pt-5 pb-3">
            <div>
              <div className="label-eyebrow mb-1">Audit feed</div>
              <div className="display-serif text-2xl">Recent events</div>
            </div>
            <Activity size={16} className="text-ink-400" />
          </div>
          <div className="divider-soft" />
          <ul className="px-6 py-4 space-y-3.5">
            {data.audit.map((e) => (
              <li key={e._id} className="text-xs flex gap-3">
                <span className="w-1.5 h-1.5 rounded-full bg-forest-500 mt-1.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-ink-800 font-mono text-[11px]">
                    {e.eventType}
                  </div>
                  <div className="text-ink-500 mt-0.5">
                    {e.actorEmail || '—'} ·{' '}
                    {new Date(e.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Layout>
  );
}
