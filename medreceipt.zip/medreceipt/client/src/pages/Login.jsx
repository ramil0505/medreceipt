import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ArrowRight, Shield, Stethoscope, FileText, Lock, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

const DEMO_ACCOUNTS = [
  { label: 'Doctor (MFA)', email: 'dr.house@medreceipt.io', password: 'Doctor!Pass123', note: 'TOTP required — see seed log' },
  { label: 'Doctor (no MFA)', email: 'dr.cuddy@medreceipt.io', password: 'Doctor!Pass123', note: '' },
  { label: 'Patient', email: 'alice@medreceipt.io', password: 'Patient!Pass123', note: '' },
  { label: 'Admin', email: 'admin@medreceipt.io', password: 'Admin!Pass123', note: '' },
];

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const { finishLogin } = useAuth();

  const fillDemo = (acc) => {
    setEmail(acc.email);
    setPassword(acc.password);
    setError('');
  };

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const r = await api.post('/auth/login', { email, password });
      const data = r.data.data;
      if (data.mfaRequired) {
        navigate('/verify-mfa', { state: { preauthToken: data.preauthToken, email } });
      } else {
        finishLogin(data);
        const dest = location.state?.from?.pathname || '/';
        navigate(dest, { replace: true });
      }
    } catch (err) {
      const msg = err.response?.data?.error?.message || 'Login failed.';
      setError(msg);
      if (err.response?.status === 423) {
        // Lockout — show retry time if available
        const retryAfter = err.response?.data?.error?.retryAfter;
        if (retryAfter) {
          const mins = Math.ceil((new Date(retryAfter) - Date.now()) / 60000);
          setError(`Account temporarily locked. Try again in ${mins} minute(s).`);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.05fr_1fr] bg-paper-50">
      {/* Left editorial panel */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 bg-forest-900 text-paper-50 overflow-hidden grain-overlay">
        <svg
          className="absolute -right-40 -bottom-40 opacity-[0.08]"
          width="700" height="700" viewBox="0 0 700 700" fill="none"
        >
          {[...Array(8)].map((_, i) => (
            <circle key={i} cx="350" cy="350" r={60 + i * 40} stroke="currentColor" strokeWidth="1" fill="none" />
          ))}
        </svg>

        <div className="relative z-10 flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-paper-50 flex items-center justify-center">
            <span className="display-serif italic text-xl text-forest-900">M</span>
          </div>
          <div>
            <div className="display-serif text-2xl">MedReceipt</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-paper-50/60">
              Digital Prescription System
            </div>
          </div>
        </div>

        <div className="relative z-10 max-w-lg">
          <div className="label-eyebrow text-paper-50/60 mb-4">Volume I — Edition 2026</div>
          <h2 className="display-serif text-5xl xl:text-6xl leading-[0.95] mb-6">
            Prescriptions,<br />
            <em className="font-extralight">unmistakable</em><br />
            and uncompromised.
          </h2>
          <p className="text-paper-50/70 text-base leading-relaxed max-w-md">
            A clinical-grade record of every diagnosis, dose and signature — encrypted in transit,
            sealed at rest, and auditable to the second.
          </p>
        </div>

        <div className="relative z-10 grid grid-cols-3 gap-4 max-w-2xl">
          {[
            { icon: Stethoscope, k: 'Doctors', v: 'Sign & dispense' },
            { icon: FileText, k: 'Patients', v: 'View & download' },
            { icon: Shield, k: 'Audit', v: 'Append-only' },
          ].map((f) => (
            <div key={f.k} className="border-t border-paper-50/15 pt-4">
              <f.icon size={16} className="mb-2 text-gold-400" strokeWidth={1.5} />
              <div className="text-xs uppercase tracking-[0.16em] text-paper-50/50">{f.k}</div>
              <div className="text-sm mt-0.5">{f.v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Right form */}
      <div className="flex flex-col justify-center px-6 sm:px-12 lg:px-16 py-10">
        <div className="w-full max-w-md mx-auto">
          <div className="lg:hidden flex items-center gap-2.5 mb-10">
            <div className="w-9 h-9 rounded-xl bg-forest-700 flex items-center justify-center">
              <span className="display-serif italic text-paper-50 text-xl">M</span>
            </div>
            <div className="display-serif text-xl">MedReceipt</div>
          </div>

          <div className="label-eyebrow mb-3">§ 01 — Authentication</div>
          <h1 className="display-serif text-5xl text-ink-900 mb-2 leading-none">Welcome back.</h1>
          <p className="text-ink-600 mb-9">
            Sign in to access prescriptions, patient records, and audit history.
          </p>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="field-label">Email</label>
              <input
                type="email"
                className="input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                autoComplete="email"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="field-label">Password</label>
                <Link to="/forgot-password" className="text-xs text-forest-700 hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  className="input pr-11"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••"
                  required
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-700"
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="text-rust-600 text-sm bg-rust-50 border border-rust-200 rounded-xl px-4 py-3 flex items-start gap-2">
                <AlertTriangle size={15} className="flex-shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
              {loading ? 'Signing in…' : 'Sign in'}
              <ArrowRight size={16} />
            </button>

            <div className="flex items-center gap-2 pt-1 text-xs text-ink-500">
              <Lock size={12} />
              Secured with bcrypt, JWT, and rate-limiting. Doctors require 2FA.
            </div>
          </form>

          <div className="mt-10 pt-6 border-t border-ink-900/10 text-sm text-ink-600">
            New patient?{' '}
            <Link to="/register" className="text-forest-700 font-medium hover:underline">
              Create an account
            </Link>
          </div>

          {/* Demo accounts */}
          <details className="mt-4 panel-flat rounded-xl text-xs text-ink-600 overflow-hidden">
            <summary className="cursor-pointer px-4 py-3 text-ink-700 font-medium hover:bg-ink-50 transition-colors">
              Demo credentials
            </summary>
            <div className="px-4 pb-3 pt-1 space-y-1.5">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.email}
                  type="button"
                  onClick={() => fillDemo(acc)}
                  className="w-full text-left flex items-center justify-between gap-3 px-3 py-2 rounded-lg hover:bg-forest-50 transition-colors group"
                >
                  <div>
                    <span className="font-medium text-ink-800 group-hover:text-forest-800">{acc.label}</span>
                    <span className="text-ink-400 ml-2 font-mono">{acc.email.split('@')[0]}</span>
                    {acc.note && <span className="ml-2 text-gold-700">[{acc.note}]</span>}
                  </div>
                  <span className="text-forest-600 opacity-0 group-hover:opacity-100 text-xs">Fill →</span>
                </button>
              ))}
            </div>
          </details>
        </div>
      </div>
    </div>
  );
}
