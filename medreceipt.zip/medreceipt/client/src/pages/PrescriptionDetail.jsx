import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ChevronLeft, Download, Check, Pill, Calendar, Hash, FileSignature } from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function PrescriptionDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [rx, setRx] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get(`/prescriptions/${id}`)
      .then((r) => setRx(r.data.data))
      .catch((e) =>
        setError(e.response?.data?.error?.message || 'Failed to load prescription.')
      );
  }, [id]);

  const sign = async () => {
    const r = await api.put(`/prescriptions/${id}/sign`);
    setRx(r.data.data);
  };
  const transition = async (status) => {
    const r = await api.put(`/prescriptions/${id}/status`, { status });
    setRx(r.data.data);
  };

  const downloadPdf = async () => {
    const token = localStorage.getItem('mr_token');
    const res = await fetch(`/api/v1/prescriptions/${id}/pdf`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.error?.message || 'Could not download PDF');
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  if (error) {
    return (
      <Layout title="Not available">
        <div className="panel p-8 text-rust-500">{error}</div>
      </Layout>
    );
  }
  if (!rx) return <Layout title="Loading…" />;

  const isDoctor = user?.role === 'DOCTOR' || user?.role === 'ADMIN';
  const isMyDraft = isDoctor && rx.status === 'DRAFT';

  return (
    <Layout
      eyebrow={`Prescription · ${rx._id.slice(-8)}`}
      title={
        <>
          {rx.medication.split(' ')[0]}{' '}
          <em className="font-extralight italic">
            {rx.medication.split(' ').slice(1).join(' ')}
          </em>
        </>
      }
      action={
        <div className="flex gap-2">
          <button onClick={() => navigate(-1)} className="btn-ghost">
            <ChevronLeft size={14} /> Back
          </button>
          {rx.status !== 'DRAFT' && (
            <button onClick={downloadPdf} className="btn-primary">
              <Download size={14} /> Download PDF
            </button>
          )}
        </div>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        {/* Document panel — looks like an editorial spread */}
        <div className="panel p-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 bg-forest-50 rounded-full blur-3xl opacity-50 -translate-y-1/3 translate-x-1/3" />
          <div className="relative">
            <div className="flex items-start justify-between mb-8">
              <div>
                <div className="label-eyebrow">Patient</div>
                <div className="display-serif text-2xl text-ink-900 mt-1">
                  {rx.patientId.fullName}
                </div>
                <div className="text-xs text-ink-500 font-mono mt-0.5">
                  {rx.patientId.personalId}
                </div>
              </div>
              <StatusBadge status={rx.status} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <Section label="Diagnosis">{rx.diagnosis}</Section>
              <Section label="Medication">
                <div className="flex items-center gap-2">
                  <Pill size={14} className="text-forest-700" /> {rx.medication}
                </div>
              </Section>
              <Section label="Dosage">{rx.dosage}</Section>
              <Section label="Prescribed by">
                {rx.doctorId.fullName}
                <div className="text-xs text-ink-500 mt-0.5">
                  Lic. {rx.doctorId.licenseNumber || '—'} · {rx.doctorId.specialty || ''}
                </div>
              </Section>
            </div>

            <div className="divider-soft mb-8" />

            <Section label="Patient instructions" full>
              <div className="text-base leading-relaxed text-ink-800">{rx.instructions}</div>
            </Section>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <Meta
                icon={Calendar}
                label="Created"
                value={new Date(rx.createdAt).toLocaleString()}
              />
              <Meta
                icon={FileSignature}
                label="Signed"
                value={rx.signedAt ? new Date(rx.signedAt).toLocaleString() : '—'}
              />
              <Meta
                icon={Calendar}
                label="Expires"
                value={rx.expiresAt ? new Date(rx.expiresAt).toLocaleDateString() : '—'}
              />
            </div>
          </div>
        </div>

        {/* Side: signature + actions */}
        <div className="space-y-5">
          <div className="panel p-6">
            <div className="label-eyebrow mb-3">E-signature</div>
            {rx.signatureHash ? (
              <>
                <div className="font-mono text-[11px] text-ink-700 break-all bg-paper-100 rounded-xl p-3 leading-relaxed">
                  {rx.signatureHash}
                </div>
                <div className="text-xs text-ink-500 mt-3 leading-relaxed">
                  SHA-256 of doctor ID, prescription ID, and the moment of signing. Tampering with
                  any field invalidates the signature.
                </div>
              </>
            ) : (
              <div className="text-sm text-ink-500">Not signed yet.</div>
            )}
          </div>

          {isDoctor && (
            <div className="panel p-6">
              <div className="label-eyebrow mb-3">Actions</div>
              <div className="space-y-2">
                {isMyDraft && (
                  <button onClick={sign} className="btn-primary w-full">
                    <Check size={14} /> Sign & activate
                  </button>
                )}
                {rx.status === 'ACTIVE' && (
                  <>
                    <button
                      onClick={() => transition('DISPENSED')}
                      className="btn-secondary w-full"
                    >
                      Mark as dispensed
                    </button>
                    <button
                      onClick={() => transition('EXPIRED')}
                      className="btn-ghost w-full text-rust-500"
                    >
                      Expire prescription
                    </button>
                  </>
                )}
                {rx.status === 'DISPENSED' && (
                  <button
                    onClick={() => transition('EXPIRED')}
                    className="btn-ghost w-full text-rust-500"
                  >
                    Expire prescription
                  </button>
                )}
                {rx.status === 'EXPIRED' && (
                  <div className="text-xs text-ink-500">
                    No further transitions available.
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="panel-flat p-5 text-xs text-ink-600 leading-relaxed">
            <div className="flex items-center gap-1.5 mb-2 text-ink-700">
              <Hash size={12} /> Audit
            </div>
            Every read of this record is logged with your user ID, timestamp, and IP. The audit
            log is append-only.
          </div>
        </div>
      </div>
    </Layout>
  );
}

function Section({ label, children, full }) {
  return (
    <div className={full ? 'col-span-full' : ''}>
      <div className="label-eyebrow mb-1.5">{label}</div>
      <div className="text-base text-ink-800 leading-relaxed">{children}</div>
    </div>
  );
}

function Meta({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2 panel-flat px-4 py-3">
      <Icon size={13} className="text-ink-500 mt-0.5" />
      <div>
        <div className="label-eyebrow">{label}</div>
        <div className="text-xs text-ink-800 mt-0.5">{value}</div>
      </div>
    </div>
  );
}
