import { useEffect, useState } from 'react';
import {
  UserCircle, Mail, Phone, Fingerprint, ShieldCheck, BadgeCheck,
  Stethoscope, Pencil, Check, X, Lock, QrCode, AlertTriangle,
  KeyRound, Eye, EyeOff, RefreshCw, ShieldOff, MapPin, Heart,
} from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const roleLabel = {
  DOCTOR: 'Attending physician',
  PATIENT: 'Registered patient',
  ADMIN: 'System operator',
};

function maskId(id) {
  if (!id) return '—';
  if (id.length <= 4) return id;
  return id.slice(0, 3) + '•••••' + id.slice(-2);
}

function Flash({ type, children }) {
  if (!children) return null;
  const cls = type === 'error'
    ? 'bg-rust-50 border-rust-200 text-rust-700'
    : 'bg-forest-50 border-forest-200 text-forest-800';
  return (
    <div className={`mb-5 px-4 py-3 rounded-xl border text-sm flex items-center gap-2 ${cls}`}>
      {type === 'success' && <BadgeCheck className="h-4 w-4 flex-shrink-0" />}
      {type === 'error' && <AlertTriangle className="h-4 w-4 flex-shrink-0" />}
      {children}
    </div>
  );
}

// ── MFA Setup Modal ───────────────────────────────────────────────────────────
function MfaSetupModal({ onClose, onSuccess }) {
  const [step, setStep] = useState('loading'); // loading | qr | confirm | done
  const [qrCode, setQrCode] = useState('');
  const [secret, setSecret] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [showSecret, setShowSecret] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.post('/auth/mfa/setup')
      .then((r) => {
        setQrCode(r.data.data.qrCode);
        setSecret(r.data.data.secret);
        setStep('qr');
      })
      .catch((e) => {
        setError(e.response?.data?.error?.message || 'Could not start MFA setup.');
        setStep('error');
      });
  }, []);

  const confirm = async () => {
    const clean = code.replace(/\s/g, '');
    if (clean.length !== 6) { setError('Enter the 6-digit code.'); return; }
    setSubmitting(true);
    setError('');
    try {
      await api.post('/auth/mfa/confirm', { code: clean });
      setStep('done');
      setTimeout(onSuccess, 1500);
    } catch (e) {
      setError(e.response?.data?.error?.message || 'Code verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/40 backdrop-blur-sm p-4">
      <div className="bg-paper-50 rounded-2xl shadow-xl w-full max-w-md p-8 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-ink-400 hover:text-ink-700">
          <X className="h-5 w-5" />
        </button>

        {step === 'loading' && (
          <div className="flex items-center justify-center py-12 text-ink-500">
            <RefreshCw className="h-6 w-6 animate-spin mr-2" /> Generating…
          </div>
        )}

        {step === 'error' && (
          <>
            <h2 className="display-serif text-2xl mb-4">Setup failed</h2>
            <Flash type="error">{error}</Flash>
            <button onClick={onClose} className="btn-secondary w-full">Close</button>
          </>
        )}

        {step === 'qr' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
                <QrCode size={20} strokeWidth={1.5} />
              </div>
              <div>
                <div className="label-eyebrow">Step 1 — Scan QR code</div>
                <div className="text-sm text-ink-600">Use Google Authenticator, Authy or similar</div>
              </div>
            </div>

            <div className="flex justify-center mb-6">
              <img src={qrCode} alt="TOTP QR code" className="w-48 h-48 rounded-xl border border-ink-200" />
            </div>

            <div className="mb-6">
              <div className="label-eyebrow mb-1">Manual entry key</div>
              <div className="flex items-center gap-2 bg-ink-50 rounded-lg px-3 py-2 border border-ink-200">
                <code className="text-xs font-mono text-ink-700 flex-1 break-all">
                  {showSecret ? secret : '••••••••••••••••••••••••••••••••'}
                </code>
                <button onClick={() => setShowSecret(!showSecret)} className="text-ink-400 hover:text-ink-700">
                  {showSecret ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            <button onClick={() => { setStep('confirm'); setError(''); }} className="btn-primary w-full">
              I've scanned the code →
            </button>
          </>
        )}

        {step === 'confirm' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
                <ShieldCheck size={20} strokeWidth={1.5} />
              </div>
              <div>
                <div className="label-eyebrow">Step 2 — Verify</div>
                <div className="text-sm text-ink-600">Enter the 6-digit code from your app</div>
              </div>
            </div>

            {error && <Flash type="error">{error}</Flash>}

            <input
              type="text"
              inputMode="numeric"
              maxLength={7}
              placeholder="000 000"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/[^\d\s]/g, ''))}
              className="input text-center text-2xl font-mono tracking-[0.3em] mb-4"
              autoFocus
            />
            <button onClick={confirm} disabled={submitting} className="btn-primary w-full mb-2">
              {submitting ? 'Verifying…' : 'Confirm and enable MFA'}
            </button>
            <button onClick={() => setStep('qr')} className="btn-ghost w-full text-sm">
              ← Back
            </button>
          </>
        )}

        {step === 'done' && (
          <div className="text-center py-8">
            <div className="w-14 h-14 rounded-full bg-forest-50 flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="h-7 w-7 text-forest-700" />
            </div>
            <h2 className="display-serif text-2xl text-forest-900 mb-2">MFA enabled!</h2>
            <p className="text-sm text-ink-600">Your account is now protected with two-factor authentication.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Disable MFA Modal ─────────────────────────────────────────────────────────
function MfaDisableModal({ onClose, onSuccess }) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    const clean = code.replace(/\s/g, '');
    if (clean.length !== 6) { setError('Enter the 6-digit code.'); return; }
    setSubmitting(true); setError('');
    try {
      await api.delete('/auth/mfa', { data: { code: clean } });
      onSuccess();
    } catch (e) {
      setError(e.response?.data?.error?.message || 'Failed to disable MFA.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/40 backdrop-blur-sm p-4">
      <div className="bg-paper-50 rounded-2xl shadow-xl w-full max-w-sm p-8 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-ink-400 hover:text-ink-700">
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-rust-50 flex items-center justify-center text-rust-600">
            <ShieldOff size={20} />
          </div>
          <div>
            <div className="label-eyebrow text-rust-500">Disable 2FA</div>
            <div className="text-sm text-ink-600">Confirm with your current TOTP</div>
          </div>
        </div>
        {error && <Flash type="error">{error}</Flash>}
        <input
          type="text"
          inputMode="numeric"
          maxLength={7}
          placeholder="000 000"
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/[^\d\s]/g, ''))}
          className="input text-center text-2xl font-mono tracking-[0.3em] mb-4"
          autoFocus
        />
        <button onClick={submit} disabled={submitting} className="w-full py-2.5 px-4 rounded-xl bg-rust-600 text-white text-sm font-medium hover:bg-rust-700 disabled:opacity-50 mb-2">
          {submitting ? 'Disabling…' : 'Disable MFA'}
        </button>
        <button onClick={onClose} className="btn-ghost w-full text-sm">Cancel</button>
      </div>
    </div>
  );
}

// ── Change Password Modal ─────────────────────────────────────────────────────
function ChangePasswordModal({ onClose, onSuccess }) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    setError('');
    if (next !== confirm) { setError('New passwords do not match.'); return; }
    if (next.length < 12) { setError('Password must be at least 12 characters.'); return; }
    setSubmitting(true);
    try {
      await api.post('/auth/change-password', { currentPassword: current, newPassword: next });
      onSuccess();
    } catch (e) {
      setError(e.response?.data?.error?.message || 'Could not change password.');
    } finally {
      setSubmitting(false);
    }
  };

  const EyeBtn = () => (
    <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-700">
      {show ? <EyeOff size={16} /> : <Eye size={16} />}
    </button>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/40 backdrop-blur-sm p-4">
      <div className="bg-paper-50 rounded-2xl shadow-xl w-full max-w-sm p-8 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-ink-400 hover:text-ink-700">
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
            <KeyRound size={20} />
          </div>
          <div className="label-eyebrow">Change password</div>
        </div>
        {error && <Flash type="error">{error}</Flash>}
        <div className="space-y-3 mb-5">
          <div className="relative">
            <label className="field-label">Current password</label>
            <input type={show ? 'text' : 'password'} className="input pr-10" value={current} onChange={e => setCurrent(e.target.value)} autoFocus />
            <EyeBtn />
          </div>
          <div className="relative">
            <label className="field-label">New password</label>
            <input type={show ? 'text' : 'password'} className="input pr-10" value={next} onChange={e => setNext(e.target.value)} />
            <EyeBtn />
          </div>
          <div className="relative">
            <label className="field-label">Confirm new password</label>
            <input type={show ? 'text' : 'password'} className="input pr-10" value={confirm} onChange={e => setConfirm(e.target.value)} />
            <EyeBtn />
          </div>
        </div>
        <p className="text-xs text-ink-500 mb-4">
          Min. 12 chars · uppercase · lowercase · digit · symbol
        </p>
        <button onClick={submit} disabled={submitting} className="btn-primary w-full mb-2">
          {submitting ? 'Saving…' : 'Update password'}
        </button>
        <button onClick={onClose} className="btn-ghost w-full text-sm">Cancel</button>
      </div>
    </div>
  );
}

// ── Main Profile Page ─────────────────────────────────────────────────────────
export default function Profile() {
  const { user, setUser } = useAuth();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [flash, setFlash] = useState(null); // { type, msg }
  const [modal, setModal] = useState(null); // 'mfa-setup' | 'mfa-disable' | 'password'

  useEffect(() => {
    if (user) setForm({
      fullName: user.fullName || '',
      phone: user.phone || '',
      address: user.address || '',
      emergencyContact: user.emergencyContact || '',
      allergies: user.allergies || '',
    });
  }, [user]);

  if (!user) return null;

  const showFlash = (type, msg) => {
    setFlash({ type, msg });
    setTimeout(() => setFlash(null), 3500);
  };

  const startEdit = () => { setEditing(true); setFlash(null); };
  const cancelEdit = () => {
    setEditing(false);
    setForm({ fullName: user.fullName || '', phone: user.phone || '', address: user.address || '', emergencyContact: user.emergencyContact || '', allergies: user.allergies || '' });
  };

  const save = async () => {
    if (!form.fullName.trim() || form.fullName.trim().length < 2) { showFlash('error', 'Full name must be at least 2 characters.'); return; }
    if (!form.phone.trim()) { showFlash('error', 'Phone is required.'); return; }
    setSaving(true);
    try {
      const r = await api.put('/users/me', form);
      setUser({ ...user, ...r.data.data });
      setEditing(false);
      showFlash('success', 'Profile updated successfully.');
    } catch (e) {
      showFlash('error', e.response?.data?.error?.message || 'Could not save changes.');
    } finally {
      setSaving(false);
    }
  };

  const initials = (user.fullName || '?').split(' ').map(p => p[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();

  const refreshUser = async () => {
    const r = await api.get('/auth/me');
    setUser(r.data.data);
  };

  return (
    <Layout eyebrow="Account" title="Profile">
      {modal === 'mfa-setup' && (
        <MfaSetupModal
          onClose={() => setModal(null)}
          onSuccess={() => { setModal(null); refreshUser(); showFlash('success', 'Two-factor authentication enabled.'); }}
        />
      )}
      {modal === 'mfa-disable' && (
        <MfaDisableModal
          onClose={() => setModal(null)}
          onSuccess={() => { setModal(null); refreshUser(); showFlash('success', 'Two-factor authentication disabled.'); }}
        />
      )}
      {modal === 'password' && (
        <ChangePasswordModal
          onClose={() => setModal(null)}
          onSuccess={() => { setModal(null); showFlash('success', 'Password changed successfully.'); }}
        />
      )}

      {flash && (
        <div className="mb-6">
          <Flash type={flash.type}>{flash.msg}</Flash>
        </div>
      )}

      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-6 max-w-6xl">
        {/* Identity card */}
        <section className="panel p-8">
          <div className="flex items-center gap-5 mb-8">
            <div className="h-20 w-20 rounded-full bg-forest-700 text-paper-50 flex items-center justify-center display-serif text-3xl shadow-soft flex-shrink-0">
              {initials || <UserCircle className="h-10 w-10" />}
            </div>
            <div className="min-w-0">
              <div className="label-eyebrow text-ink-400 mb-1">{roleLabel[user.role] || user.role}</div>
              <h2 className="display-serif text-3xl text-ink-900 leading-tight truncate">{user.fullName}</h2>
              <div className="flex items-center gap-2 mt-1 text-sm text-ink-500">
                <Mail className="h-3.5 w-3.5" />
                <span className="truncate">{user.email}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-6">
            <div>
              <label className="field-label">Full name</label>
              {editing
                ? <input className="input" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} disabled={saving} />
                : <div className="text-ink-900 text-base">{user.fullName}</div>}
            </div>
            <div>
              <label className="field-label">Phone</label>
              {editing
                ? <input className="input" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} disabled={saving} placeholder="+371 …" />
                : <div className="text-ink-900 text-base flex items-center gap-2"><Phone className="h-4 w-4 text-ink-400" />{user.phone || <span className="text-ink-400">Not set</span>}</div>}
            </div>
            {user.role === 'PATIENT' && (
              <>
                <div>
                  <label className="field-label">Address</label>
                  {editing
                    ? <input className="input" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} disabled={saving} placeholder="Street, city, postcode" />
                    : <div className="text-ink-900 text-base flex items-center gap-2"><MapPin className="h-4 w-4 text-ink-400" />{user.address || <span className="text-ink-400">Not set</span>}</div>}
                </div>
                <div>
                  <label className="field-label">Emergency contact</label>
                  {editing
                    ? <input className="input" value={form.emergencyContact} onChange={e => setForm({ ...form, emergencyContact: e.target.value })} disabled={saving} placeholder="Name + phone" />
                    : <div className="text-ink-900 text-sm">{user.emergencyContact || <span className="text-ink-400">Not set</span>}</div>}
                </div>
                <div>
                  <label className="field-label">Known allergies</label>
                  {editing
                    ? <textarea className="input min-h-[70px] resize-y" value={form.allergies} onChange={e => setForm({ ...form, allergies: e.target.value })} disabled={saving} placeholder="e.g. Penicillin, latex…" />
                    : <div className="text-ink-900 text-sm">{user.allergies || <span className="text-ink-400">None recorded</span>}</div>}
                </div>
              </>
            )}
            <div>
              <label className="field-label">Email <span className="text-ink-400 font-normal">(read-only)</span></label>
              <div className="text-ink-700 text-base flex items-center gap-2"><Mail className="h-4 w-4 text-ink-400" />{user.email}</div>
            </div>
          </div>

          <div className="pt-6 border-t border-ink-100 flex gap-3 flex-wrap">
            {editing ? (
              <>
                <button onClick={save} disabled={saving} className="btn-primary">
                  <Check className="h-4 w-4" />{saving ? 'Saving…' : 'Save changes'}
                </button>
                <button onClick={cancelEdit} disabled={saving} className="btn-secondary">
                  <X className="h-4 w-4" />Cancel
                </button>
              </>
            ) : (
              <>
                <button onClick={startEdit} className="btn-primary">
                  <Pencil className="h-4 w-4" />Edit details
                </button>
                <button onClick={() => setModal('password')} className="btn-secondary">
                  <KeyRound className="h-4 w-4" />Change password
                </button>
              </>
            )}
          </div>
        </section>

        {/* Right column */}
        <div className="space-y-6">
          {/* Identifiers */}
          <section className="panel p-7">
            <div className="label-eyebrow mb-4">Identifiers</div>
            <dl className="space-y-4 text-sm">
              <div className="flex items-start justify-between gap-4">
                <dt className="text-ink-500 flex items-center gap-2"><Fingerprint className="h-3.5 w-3.5" /> Personal ID</dt>
                <dd className="font-mono text-ink-900">{maskId(user.personalId)}</dd>
              </div>
              <div className="flex items-start justify-between gap-4">
                <dt className="text-ink-500">Account ID</dt>
                <dd className="font-mono text-ink-700 text-xs truncate max-w-[200px]">{user._id || user.id}</dd>
              </div>
              {user.role === 'PATIENT' && user.bloodType && (
                <div className="flex items-start justify-between gap-4">
                  <dt className="text-ink-500 flex items-center gap-2"><Heart className="h-3.5 w-3.5" /> Blood type</dt>
                  <dd className="font-mono text-ink-900 font-medium">{user.bloodType}</dd>
                </div>
              )}
              {user.role === 'DOCTOR' && (
                <>
                  <div className="flex items-start justify-between gap-4">
                    <dt className="text-ink-500 flex items-center gap-2"><Stethoscope className="h-3.5 w-3.5" /> Specialty</dt>
                    <dd className="text-ink-900">{user.specialty || '—'}</dd>
                  </div>
                  <div className="flex items-start justify-between gap-4">
                    <dt className="text-ink-500">Department</dt>
                    <dd className="text-ink-900">{user.department || '—'}</dd>
                  </div>
                  <div className="flex items-start justify-between gap-4">
                    <dt className="text-ink-500">License</dt>
                    <dd className="font-mono text-ink-900">{user.licenseNumber || '—'}</dd>
                  </div>
                </>
              )}
              {user.lastLoginAt && (
                <div className="flex items-start justify-between gap-4">
                  <dt className="text-ink-500">Last login</dt>
                  <dd className="text-ink-700 text-xs">{new Date(user.lastLoginAt).toLocaleString()}</dd>
                </div>
              )}
            </dl>
          </section>

          {/* Security posture */}
          <section className="panel p-7">
            <div className="label-eyebrow mb-4">Security</div>
            <ul className="space-y-3 text-sm mb-6">
              <li className="flex items-center gap-3">
                <span className={`h-2 w-2 rounded-full ${user.mfaEnabled ? 'bg-forest-600' : 'bg-ink-300'}`} />
                <span className="text-ink-700 flex-1">Two-factor authentication</span>
                <span className={`text-xs font-medium ${user.mfaEnabled ? 'text-forest-700' : 'text-ink-500'}`}>
                  {user.mfaEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <span className={`h-2 w-2 rounded-full ${user.isVerified ? 'bg-forest-600' : 'bg-gold-500'}`} />
                <span className="text-ink-700 flex-1">Email verification</span>
                <span className={`text-xs font-medium ${user.isVerified ? 'text-forest-700' : 'text-gold-700'}`}>
                  {user.isVerified ? 'Verified' : 'Pending'}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-forest-600" />
                <span className="text-ink-700 flex-1">Password hashing</span>
                <span className="text-xs font-medium text-forest-700">bcrypt cost 12</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-forest-600" />
                <span className="text-ink-700 flex-1">Session token</span>
                <span className="text-xs font-medium text-forest-700">JWT, short-lived</span>
              </li>
            </ul>

            <div className="flex flex-col gap-2">
              {user.mfaEnabled ? (
                <button
                  onClick={() => setModal('mfa-disable')}
                  className="w-full py-2.5 px-4 rounded-xl border border-rust-200 text-rust-600 text-sm font-medium hover:bg-rust-50 flex items-center justify-center gap-2 transition-colors"
                >
                  <ShieldOff className="h-4 w-4" />Disable two-factor authentication
                </button>
              ) : (
                <button
                  onClick={() => setModal('mfa-setup')}
                  className="w-full py-2.5 px-4 rounded-xl bg-forest-50 border border-forest-200 text-forest-800 text-sm font-medium hover:bg-forest-100 flex items-center justify-center gap-2 transition-colors"
                >
                  <ShieldCheck className="h-4 w-4" />Enable two-factor authentication
                </button>
              )}
            </div>

            <div className="mt-5 pt-5 border-t border-ink-100 flex items-start gap-3 text-xs text-ink-500 leading-relaxed">
              <ShieldCheck className="h-4 w-4 text-forest-600 flex-shrink-0 mt-0.5" />
              <p>All sensitive actions are recorded in the immutable audit log. Personal identifiers are masked by default.</p>
            </div>
          </section>
        </div>
      </div>
    </Layout>
  );
}
