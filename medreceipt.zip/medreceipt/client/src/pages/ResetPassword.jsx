import { useState, useEffect } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { KeyRound, ArrowRight, Eye, EyeOff, AlertTriangle, BadgeCheck } from 'lucide-react';
import api from '../api/client.js';

const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{12,}$/;

function StrengthBar({ password }) {
  let score = 0;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[a-z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  const colors = ['bg-ink-200', 'bg-rust-400', 'bg-gold-400', 'bg-gold-400', 'bg-forest-500', 'bg-forest-600'];
  const labels = ['', 'Very weak', 'Weak', 'Fair', 'Good', 'Strong'];

  return (
    <div className="mt-1.5">
      <div className="flex gap-1 mb-1">
        {[1,2,3,4,5].map(i => (
          <div key={i} className={`h-1 flex-1 rounded-full transition-colors ${i <= score ? colors[score] : 'bg-ink-100'}`} />
        ))}
      </div>
      {password && <div className="text-xs text-ink-400">{labels[score]}</div>}
    </div>
  );
}

export default function ResetPassword() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const token = params.get('token') || '';

  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const mismatch = confirm && newPassword !== confirm;
  const canSubmit = PASSWORD_RE.test(newPassword) && newPassword === confirm && !loading;

  const submit = async (e) => {
    e.preventDefault();
    if (!canSubmit) return;
    setLoading(true);
    setError('');
    try {
      await api.post('/auth/reset-password', { resetToken: token, newPassword });
      setDone(true);
      setTimeout(() => navigate('/login'), 3000);
    } catch (err) {
      setError(err.response?.data?.error?.message || 'Reset failed. The link may have expired.');
    } finally {
      setLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6 bg-paper-50">
        <div className="panel p-10 max-w-md w-full text-center">
          <AlertTriangle className="h-10 w-10 text-rust-500 mx-auto mb-4" />
          <h1 className="display-serif text-2xl mb-2">Invalid link</h1>
          <p className="text-sm text-ink-600 mb-6">This reset link is missing or malformed.</p>
          <Link to="/forgot-password" className="btn-primary inline-flex">Request a new link</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-paper-50">
      <div className="w-full max-w-md">
        <div className="panel p-10 fade-up">

          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center text-forest-700">
              <KeyRound size={20} strokeWidth={1.5} />
            </div>
            <div className="label-eyebrow">Set new password</div>
          </div>

          {!done ? (
            <>
              <h1 className="display-serif text-4xl text-ink-900 mb-2 leading-none">
                Choose a new password.
              </h1>
              <p className="text-sm text-ink-600 mb-8">
                Minimum 12 characters — include uppercase, lowercase, a digit, and a symbol.
              </p>

              <form onSubmit={submit} className="space-y-4">
                <div>
                  <label className="field-label">New password</label>
                  <div className="relative">
                    <input
                      type={show ? 'text' : 'password'}
                      className="input pr-11"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••••••"
                      autoFocus
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShow(!show)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-700"
                    >
                      {show ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <StrengthBar password={newPassword} />
                </div>

                <div>
                  <label className="field-label">Confirm password</label>
                  <input
                    type={show ? 'text' : 'password'}
                    className={`input ${mismatch ? 'border-rust-400 focus:border-rust-500 focus:ring-rust-400/10' : ''}`}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="••••••••••••"
                    autoComplete="new-password"
                  />
                  {mismatch && (
                    <p className="text-xs text-rust-600 mt-1">Passwords don't match.</p>
                  )}
                </div>

                {error && (
                  <div className="text-rust-600 text-sm bg-rust-50 border border-rust-200 rounded-xl px-4 py-3 flex items-start gap-2">
                    <AlertTriangle size={15} className="flex-shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <button type="submit" disabled={!canSubmit} className="btn-primary w-full disabled:opacity-50">
                  {loading ? 'Resetting…' : 'Reset password'}
                  <ArrowRight size={16} />
                </button>
              </form>

              <div className="mt-6 text-center">
                <Link to="/forgot-password" className="text-sm text-ink-500 hover:text-ink-800">
                  Request a new link
                </Link>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <div className="w-14 h-14 rounded-full bg-forest-50 flex items-center justify-center mx-auto mb-5">
                <BadgeCheck className="h-7 w-7 text-forest-700" />
              </div>
              <h1 className="display-serif text-3xl text-ink-900 mb-2">Password reset.</h1>
              <p className="text-sm text-ink-600">Redirecting you to login in a moment…</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
