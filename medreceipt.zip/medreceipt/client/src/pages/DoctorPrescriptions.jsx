import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, FileText } from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';
import StatusBadge from '../components/StatusBadge.jsx';

const tabs = ['ALL', 'DRAFT', 'ACTIVE', 'DISPENSED', 'EXPIRED'];

export default function DoctorPrescriptions() {
  const [items, setItems] = useState([]);
  const [tab, setTab] = useState('ALL');

  useEffect(() => {
    const params = { limit: 100 };
    if (tab !== 'ALL') params.status = tab;
    api.get('/prescriptions', { params }).then((r) => setItems(r.data.data));
  }, [tab]);

  return (
    <Layout
      eyebrow="Catalogue"
      title={
        <>
          All <em className="font-extralight italic">prescriptions</em>
        </>
      }
    >
      <div className="flex gap-1 mb-5 panel-flat p-1 inline-flex">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium transition ${
              tab === t ? 'bg-forest-700 text-paper-50' : 'text-ink-700 hover:bg-paper-200/70'
            }`}
          >
            {t.charAt(0) + t.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      <div className="panel overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="text-left">
              <th className="label-eyebrow px-6 py-4">Patient</th>
              <th className="label-eyebrow px-6 py-4 hidden md:table-cell">Medication</th>
              <th className="label-eyebrow px-6 py-4 hidden lg:table-cell">Diagnosis</th>
              <th className="label-eyebrow px-6 py-4">Status</th>
              <th className="label-eyebrow px-6 py-4 hidden md:table-cell">Created</th>
              <th className="label-eyebrow px-6 py-4 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-900/[0.05]">
            {items.map((rx, i) => (
              <tr
                key={rx._id}
                className="hover:bg-paper-100/60 transition fade-up"
                style={{ animationDelay: `${Math.min(i * 25, 250)}ms` }}
              >
                <td className="px-6 py-4">
                  <div className="text-sm text-ink-900">{rx.patientId?.fullName}</div>
                  <div className="text-xs text-ink-500 font-mono">
                    {rx.patientId?.personalId}
                  </div>
                </td>
                <td className="px-6 py-4 hidden md:table-cell text-sm text-ink-800">
                  {rx.medication}
                </td>
                <td className="px-6 py-4 hidden lg:table-cell text-xs text-ink-600 max-w-[260px] truncate">
                  {rx.diagnosis}
                </td>
                <td className="px-6 py-4">
                  <StatusBadge status={rx.status} />
                </td>
                <td className="px-6 py-4 hidden md:table-cell text-xs text-ink-500">
                  {new Date(rx.createdAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 text-right">
                  <Link
                    to={`/prescriptions/${rx._id}`}
                    className="text-xs text-forest-700 hover:underline inline-flex items-center gap-1"
                  >
                    Open <ArrowRight size={12} />
                  </Link>
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-16 text-center text-sm text-ink-500">
                  <FileText size={32} className="mx-auto mb-3 text-ink-400" />
                  No prescriptions match this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
