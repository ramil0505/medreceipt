import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ArrowRight, UserCircle } from 'lucide-react';
import api from '../api/client.js';
import Layout from '../components/Layout.jsx';

export default function PatientsList() {
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => {
      setLoading(true);
      api
        .get('/users', { params: { search, limit: 50 } })
        .then((r) => setPatients(r.data.data))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [search]);

  return (
    <Layout
      eyebrow="Index of patients"
      title={
        <>
          Patients
          <span className="text-ink-400 font-extralight italic"> ·</span>{' '}
          <em className="font-extralight italic text-ink-500">{patients.length}</em>
        </>
      }
    >
      <div className="panel mb-6 px-5 py-3 flex items-center gap-3">
        <Search size={16} className="text-ink-500" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, email, or personal ID…"
          className="flex-1 bg-transparent outline-none text-sm placeholder:text-ink-400"
        />
        {loading && <span className="text-xs text-ink-400">Searching…</span>}
      </div>

      <div className="panel overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="text-left">
              <th className="label-eyebrow px-6 py-4">Patient</th>
              <th className="label-eyebrow px-6 py-4 hidden md:table-cell">Personal ID</th>
              <th className="label-eyebrow px-6 py-4 hidden md:table-cell">Phone</th>
              <th className="label-eyebrow px-6 py-4 hidden lg:table-cell">Registered</th>
              <th className="label-eyebrow px-6 py-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-900/[0.05]">
            {patients.map((p, i) => (
              <tr
                key={p._id}
                className="hover:bg-paper-100/60 transition fade-up"
                style={{ animationDelay: `${Math.min(i * 30, 300)}ms` }}
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-forest-50 text-forest-700 flex items-center justify-center text-xs font-semibold">
                      {p.fullName?.split(' ').map((s) => s[0]).slice(0, 2).join('')}
                    </div>
                    <div>
                      <div className="text-sm text-ink-900">{p.fullName}</div>
                      <div className="text-xs text-ink-500">{p.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 hidden md:table-cell text-sm font-mono text-ink-700">
                  {p.personalId}
                </td>
                <td className="px-6 py-4 hidden md:table-cell text-sm text-ink-700">{p.phone}</td>
                <td className="px-6 py-4 hidden lg:table-cell text-sm text-ink-500">
                  {new Date(p.createdAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 text-right">
                  <Link
                    to={`/doctor/patients/${p._id}`}
                    className="inline-flex items-center gap-1 text-xs text-forest-700 hover:underline"
                  >
                    Open file <ArrowRight size={12} />
                  </Link>
                </td>
              </tr>
            ))}
            {patients.length === 0 && !loading && (
              <tr>
                <td colSpan={5} className="px-6 py-16 text-center text-sm text-ink-500">
                  <UserCircle size={32} className="mx-auto mb-3 text-ink-400" />
                  No patients match your search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
