import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ChevronLeft, Check } from 'lucide-react';
import api from '../api/client.js';

export default function Register() {
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    password: '',
    personalId: '',
    phone: '',
    dateOfBirth: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const ch = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const checks = [
    { ok: form.password.length >= 12, label: '12+ characters' },
    { ok: /[a-z]/.test(form.password), label: 'lowercase letter' },
    { ok: /[A-Z]/.test(form.password), label: 'uppercase letter' },
    { ok: /\d/.test(form.password), label: 'digit' },
    { ok: /[^A-Za-z0-9]/.test(form.password), label: 'symbol' },
  ];

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.post('/auth/register', form);
      navigate('/login', { state: { justRegistered: true } });
    } catch (err) {
      setError(err.response?.data?.error?.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-[1fr_1.05fr] bg-paper-50">
      <div className="flex flex-col justify-center px-6 sm:px-12 lg:px-16 py-10 order-2 lg:order-1">
        <div className="w-full max-w-md mx-auto">
          <Link to="/login" className="inline-flex items-center gap-1 text-sm text-ink-600 mb-8 hover:text-ink-900">
            <ChevronLeft size={14} /> Back to sign in
          </Link>
          <div className="label-eyebrow mb-3">§ 02 — Patient enrolment</div>
          <h1 className="display-serif text-5xl text-ink-900 mb-2 leading-none">Begin your file.</h1>
          <p className="text-ink-600 mb-8">
            Create a patient account to receive prescriptions and access your full medical
            history.
          </p>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="field-label">Full name</label>
              <input className="input" value={form.fullName} onChange={ch('fullName')} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="field-label">Email</label>
                <input
                  type="email"
                  className="input"
                  value={form.email}
                  onChange={ch('email')}
                  required
                />
              </div>
              <div>
                <label className="field-label">Phone</label>
                <input className="input" value={form.phone} onChange={ch('phone')} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="field-label">Personal ID</label>
                <input
                  className="input"
                  value={form.personalId}
                  onChange={ch('personalId')}
                  required
                />
              </div>
              <div>
                <label className="field-label">Date of birth</label>
                <input
                  type="date"
                  className="input"
                  value={form.dateOfBirth}
                  onChange={ch('dateOfBirth')}
                />
              </div>
            </div>
            <div>
              <label className="field-label">Password</label>
              <input
                type="password"
                className="input"
                value={form.password}
                onChange={ch('password')}
                required
              />
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 mt-3">
                {checks.map((c) => (
                  <div
                    key={c.label}
                    className={`flex items-center gap-1.5 text-[11px] ${
                      c.ok ? 'text-forest-700' : 'text-ink-500'
                    }`}
                  >
                    <span
                      className={`w-3.5 h-3.5 rounded-full flex items-center justify-center ${
                        c.ok ? 'bg-forest-700 text-paper-50' : 'bg-paper-200'
                      }`}
                    >
                      {c.ok && <Check size={9} strokeWidth={3} />}
                    </span>
                    {c.label}
                  </div>
                ))}
              </div>
            </div>

            {error && (
              <div className="text-rust-500 text-sm bg-rust-400/10 border border-rust-400/20 rounded-xl px-4 py-2.5">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
              {loading ? 'Creating account…' : 'Create account'}
              <ArrowRight size={16} />
            </button>
          </form>
        </div>
      </div>

      <div className="relative hidden lg:flex flex-col justify-between p-12 bg-forest-900 text-paper-50 overflow-hidden grain-overlay order-1 lg:order-2">
        <div className="relative z-10 flex justify-end">
          <div className="text-[10px] uppercase tracking-[0.18em] text-paper-50/60">
            Confidential · Group W
          </div>
        </div>
        <div className="relative z-10">
          <div className="label-eyebrow text-paper-50/60 mb-4">A note on your data</div>
          <h2 className="display-serif text-5xl leading-[0.95] mb-6">
            Encrypted, <em className="font-extralight">always</em>.
            <br />
            Yours, <em className="font-extralight">solely</em>.
          </h2>
          <p className="text-paper-50/70 text-base leading-relaxed max-w-md">
            Your records are stored under non-guessable identifiers, transmitted over TLS, and
            accessible only to your treating clinicians. Every read of your file is logged.
          </p>
        </div>
        <div className="relative z-10 text-xs text-paper-50/50 max-w-sm">
          By creating an account you acknowledge MedReceipt's role as a Data Controller under the
          GDPR. Subject access requests honoured within 30 days.
        </div>
      </div>
    </div>
  );
}
