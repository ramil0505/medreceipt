export default function StatusBadge({ status }) {
  const map = {
    DRAFT: { cls: 'chip-draft', label: 'Draft' },
    ACTIVE: { cls: 'chip-active', label: 'Active' },
    DISPENSED: { cls: 'chip-dispensed', label: 'Dispensed' },
    EXPIRED: { cls: 'chip-expired', label: 'Expired' },
  };
  const c = map[status] || map.DRAFT;
  return (
    <span className={c.cls}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60" />
      {c.label}
    </span>
  );
}
