import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  FileText,
  ScrollText,
  UserCircle,
  LogOut,
  ShieldCheck,
  Activity,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';

const navByRole = {
  DOCTOR: [
    { to: '/doctor', label: 'Overview', icon: LayoutDashboard, end: true },
    { to: '/doctor/patients', label: 'Patients', icon: Users },
    { to: '/doctor/prescriptions', label: 'Prescriptions', icon: FileText },
    { to: '/audit', label: 'Audit log', icon: ScrollText },
    { to: '/profile', label: 'Profile', icon: UserCircle },
  ],
  PATIENT: [
    { to: '/patient', label: 'My Prescriptions', icon: FileText, end: true },
    { to: '/profile', label: 'Profile', icon: UserCircle },
  ],
  ADMIN: [
    { to: '/admin', label: 'Operations', icon: LayoutDashboard, end: true },
    { to: '/admin/users', label: 'Users', icon: Users },
    { to: '/audit', label: 'Audit log', icon: ScrollText },
    { to: '/profile', label: 'Profile', icon: UserCircle },
  ],
};

export default function Layout({ children, eyebrow, title, action }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const items = navByRole[user?.role] || [];

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen flex bg-paper-50">
      {/* Sidebar */}
      <aside className="hidden md:flex w-64 flex-col border-r border-ink-900/[0.06] bg-paper-100/60">
        <div className="px-6 pt-7 pb-6">
          <div className="flex items-center gap-2.5">
            <div className="relative w-9 h-9 rounded-xl bg-forest-700 flex items-center justify-center shadow-soft">
              <span className="display-serif text-paper-50 text-xl italic">M</span>
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-gold-400 ring-2 ring-paper-100" />
            </div>
            <div>
              <div className="display-serif text-xl text-ink-900 leading-none">MedReceipt</div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-ink-500 mt-0.5">
                Group&nbsp;W
              </div>
            </div>
          </div>
        </div>

        <nav className="px-3 flex-1 space-y-0.5">
          {items.map((it) => (
            <NavLink
              key={it.to}
              to={it.to}
              end={it.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm transition ${
                  isActive
                    ? 'bg-forest-700 text-paper-50 shadow-soft'
                    : 'text-ink-700 hover:bg-paper-200/70'
                }`
              }
            >
              <it.icon size={16} strokeWidth={1.75} />
              {it.label}
            </NavLink>
          ))}
        </nav>

        <div className="m-3 p-3.5 panel">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck size={14} className="text-forest-600" />
            <div className="text-[11px] font-medium text-ink-700">Security mode</div>
          </div>
          <div className="text-xs text-ink-600 leading-relaxed">
            JWT · bcrypt-12 · {user?.role === 'DOCTOR' ? 'TOTP MFA' : 'RBAC'} · Append-only audit
          </div>
        </div>

        <div className="px-3 pb-4">
          <div className="px-3.5 py-3 rounded-xl bg-white/60 border border-ink-900/[0.06] flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-forest-100 flex items-center justify-center text-forest-700 text-xs font-semibold">
              {user?.fullName?.split(' ').map((s) => s[0]).slice(0, 2).join('')}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm text-ink-900 truncate">{user?.fullName}</div>
              <div className="text-[11px] text-ink-500 truncate">{user?.email}</div>
            </div>
            <button
              onClick={handleLogout}
              className="p-1.5 rounded-lg hover:bg-paper-200 text-ink-600"
              title="Logout"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 min-w-0">
        <header className="px-6 md:px-12 pt-10 pb-8">
          <div className="flex items-end justify-between gap-6 flex-wrap">
            <div className="fade-up">
              {eyebrow && <div className="label-eyebrow mb-2">{eyebrow}</div>}
              <h1 className="display-serif text-5xl md:text-6xl text-ink-900 leading-[0.95]">
                {title}
              </h1>
            </div>
            {action && <div className="fade-up" style={{ animationDelay: '60ms' }}>{action}</div>}
          </div>
        </header>
        <div className="px-6 md:px-12 pb-16 fade-up" style={{ animationDelay: '120ms' }}>
          {children}
        </div>
      </main>
    </div>
  );
}
