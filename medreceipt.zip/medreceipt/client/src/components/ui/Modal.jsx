import { useEffect } from 'react';
import { X } from 'lucide-react';

export default function Modal({ open, onClose, title, subtitle, children, size = 'md' }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);
  if (!open) return null;
  const widths = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-ink-900/40 backdrop-blur-sm fade-up"
        onClick={onClose}
      />
      <div
        className={`relative w-full ${widths[size]} bg-paper-50 rounded-3xl shadow-2xl border border-ink-900/10 fade-up`}
      >
        <div className="flex items-start justify-between px-7 pt-6 pb-3">
          <div>
            {subtitle && <div className="label-eyebrow mb-1">{subtitle}</div>}
            <h2 className="display-serif text-2xl text-ink-900">{title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-paper-200 transition"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>
        <div className="divider-soft" />
        <div className="p-7 pt-5">{children}</div>
      </div>
    </div>
  );
}
