import { createContext, useContext, useEffect, useState } from 'react';
import api from '../api/client.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('mr_user');
    return raw ? JSON.parse(raw) : null;
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('mr_token');
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get('/auth/me')
      .then((r) => {
        setUser(r.data.data);
        localStorage.setItem('mr_user', JSON.stringify(r.data.data));
      })
      .catch(() => {
        localStorage.removeItem('mr_token');
        localStorage.removeItem('mr_user');
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  const finishLogin = ({ token, user }) => {
    localStorage.setItem('mr_token', token);
    localStorage.setItem('mr_user', JSON.stringify(user));
    setUser(user);
  };

  const logout = async () => {
    try {
      await api.post('/auth/logout');
    } catch {}
    localStorage.removeItem('mr_token');
    localStorage.removeItem('mr_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, finishLogin, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
